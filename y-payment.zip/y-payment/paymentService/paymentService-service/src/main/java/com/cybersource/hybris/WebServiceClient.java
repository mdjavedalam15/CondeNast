package com.cybersource.hybris;

import org.apache.log4j.Logger;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.cybersource.hybris.util.CSUtil;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.common.utils.StringUtils;

import java.util.Properties;


/**
 *
 */
public class WebServiceClient extends WebServiceTemplate
{
	private static final Logger LOG = Logger.getLogger(WebServiceClient.class);
	

	public String merchantID;
	public static String serverUrl;

	// remained here to avoid empty values of a library.properties files
	public static String DEFAULT_CLIENT_LIBRARY = "hybris_default";
	public static String DEFAULT_LIB_VERSION = "0.0.0";

	private Properties libraryProperties;

	public ReplyMessage sendReceive(final RequestMessage requestMessage)
	{
		ReplyMessage replyMessage = null;
		try
		{
			setDefaultUri(getServerUrl());
			System.out.println(getServerUrl());

			requestMessage.setMerchantID(this.getMerchantID());
			System.out.println(getMerchantID());

			// Before using this example, replace the generic value with
			// your reference number for the current transaction.
			if (StringUtils.isBlank(requestMessage.getMerchantReferenceCode())) {
				requestMessage.setMerchantReferenceCode("1");	
				requestMessage.setMerchantTransactionIdentifier("1");
			}

			// To help us troubleshoot any problems that you may encounter,
			// please include the following information about your application.
			String client = libraryProperties.getProperty("payment.service.client.library", DEFAULT_CLIENT_LIBRARY);
			String libVersion = libraryProperties.getProperty("payment.service.client.library.version", DEFAULT_LIB_VERSION);

			requestMessage.setClientLibrary(client);
			requestMessage.setClientLibraryVersion(libVersion);
			requestMessage.setClientEnvironment(System.getProperty("os.name") + "/" + System.getProperty("os.version") + "/"
					+ System.getProperty("java.vendor") + "/" + System.getProperty("java.version"));

			replyMessage = (ReplyMessage) marshalSendAndReceive(requestMessage);

			CSUtil.log(LOG, requestMessage, replyMessage);
			
		}
		catch (final Exception e)
		{
			LOG.error(e);
		}
		return replyMessage;
	}
	
	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public static String getServerUrl() {
		return serverUrl;
	}

	public static void setServerUrl(String serverUrl) {
		WebServiceClient.serverUrl = serverUrl;
	}

	public Properties getLibraryProperties() {
		return libraryProperties;
	}

	public void setLibraryProperties(Properties libraryProperties) {
		this.libraryProperties = libraryProperties;
	}
}
