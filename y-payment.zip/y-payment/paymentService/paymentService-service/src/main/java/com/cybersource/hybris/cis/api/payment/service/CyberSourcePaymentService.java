package com.cybersource.hybris.cis.api.payment.service;


import java.math.BigDecimal;
import java.util.Map;

import javax.annotation.Resource;
//import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybersource.hybris.payment.executor.CyberSourceAuthorizeExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceAuthorizeWithProfileExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceCaptureExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceDeleteProfileExecutor;
import com.cybersource.hybris.payment.executor.CyberSourcePayerAuthExecutor;
import com.cybersource.hybris.payment.executor.CyberSourcePayerAuthValidateExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceRefundExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceReverseExecutor;
import com.cybersource.hybris.payment.executor.CyberSourceUpdateProfileExecutor;
import com.cybersource.hybris.util.CSUtil;
import com.cybersource.secureacceptance.CyberSourceResponseHandler;
import com.hybris.cis.api.exception.ServiceNotImplementedException;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisResult;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisCreditCardAuthorization;
import com.hybris.cis.api.payment.model.CisExternalPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentProfileRequest;
import com.hybris.cis.api.payment.model.CisPaymentProfileResult;
import com.hybris.cis.api.payment.model.CisPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentSessionInitRequest;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentCapture;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentRefund;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentReverse;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentTransactionResult;
import com.hybris.cis.api.payment.service.PaymentService;
import com.hybris.cis.api.service.CisServiceType;
//import org.apache.log4j.Logger;
//import org.springframework.stereotype.Component;
import com.cybersource.hybris.payment.executor.tokenized.CyberSourceTokenizedCaptureExecutor;
import com.cybersource.hybris.payment.executor.tokenized.CyberSourceTokenizedRefundExecutor;
import com.cybersource.hybris.payment.executor.tokenized.CyberSourceTokenizedReverseExecutor;



public class CyberSourcePaymentService implements PaymentService
{
	private static final Logger LOG = LoggerFactory.getLogger(CyberSourcePaymentService.class);

	
	private static final String SERVICE_ID = "paymentService";
	private String hpfUrl;	
	
	@Resource
	CyberSourceUpdateProfileExecutor cyberSourceUpdateProfileExecutor;
	
	@Resource
	CyberSourceDeleteProfileExecutor cyberSourceDeleteProfileExecutor;
	
	@Resource
	CyberSourceResponseHandler cyberSourceResponseHandler;
	
	@Resource
	CyberSourceCaptureExecutor cyberSourceCaptureExecutor;

	@Resource
	CyberSourceTokenizedCaptureExecutor cyberSourceTokenizedCaptureExecutor;

	@Resource
	CyberSourceReverseExecutor cyberSourceReverseExecutor;

	@Resource
	CyberSourceTokenizedReverseExecutor cyberSourceTokenizedReverseExecutor;

	@Resource
	CyberSourceRefundExecutor cyberSourceRefundExecutor;

	@Resource
	CyberSourceTokenizedRefundExecutor cyberSourceTokenizedRefundExecutor;
	
	@Resource
	CyberSourceAuthorizeExecutor cyberSourceAuthorizeExecutor;

	@Resource
	CyberSourceAuthorizeWithProfileExecutor cyberSourceAuthorizeWithProfileExecutor;
	

	@Resource
	CyberSourcePayerAuthExecutor cyberSourcePayerAuthExecutor;
	
	@Resource
	CyberSourcePayerAuthValidateExecutor cyberSourcePayerAuthValidateExecutor;
	
	
	@Override
	public String getId()
	{
		return SERVICE_ID;
	}

	@Override
	public CisServiceType getType()
	{
		return CisServiceType.PSP;
	}

	/**
     * @param paymentRequest
     *           CisPaymentAuthorization
     * @param profileId
     *           the profile id
     * @return CisPaymentTransactionResult an authorization with an accept decision, A123 as order id, 456 as request id.
     *         Throws an NotFoundException if the profileId equals notValidCustomerProfileID
     */
    @Override
    public CisPaymentTransactionResult authorize(final CisPaymentAuthorization paymentRequest, final String profileId)
    {
    	return cyberSourceAuthorizeWithProfileExecutor.execute(new Pair <String, CisPaymentAuthorization>(profileId, paymentRequest));
    }

	/**
	 * @param paymentRequest
	 *           - a CIS payment request with at least the amount and currency set.
	 * @return returns a valid authorization for the set amount which is verified with the order number A123 and the
	 *         request id 456.
	 */
	@Override
	public CisPaymentTransactionResult authorize(final CisCreditCardAuthorization paymentRequest)
	{
		
		LOG.info("authorize");
    	System.out.println("authorize with profile");
	    return cyberSourceAuthorizeExecutor.execute(paymentRequest);
	}

	/**
	 * @param paymentRequest
	 *           - a CIS payment request with at least the amount and currency set.
	 * @param transactionId
	 *           a transaction id
	 * @param clientAuthorizationId
	 *           the client authorization id
	 * @return returns a valid re-authorization for the set amount which is verified with the order number RA123 and the
	 *         request id 456.
	 */
	@Override
	public CisPaymentTransactionResult reauthorize(final CisPaymentAuthorization paymentRequest, final String transactionId,
			final String clientAuthorizationId)
	{
		throw new ServiceNotImplementedException( "reauthorize" );
	}

	/**
	 * @param paymentRequest
	 *           - a CIS payment request with at least the amount and currency set.
	 * @param transactionId
	 *           a transaction id
	 * @param clientAuthorizationId
	 *           the client authorization id
	 * @return reverses an authorization and returns REV123 as ID
	 */
	@Override
	public CisPaymentTransactionResult reverse(final CisPaymentRequest paymentRequest, final String transactionId,
			final String clientAuthorizationId)
	{
		return cyberSourceReverseExecutor.execute(new Pair<String, CisPaymentRequest> (transactionId, paymentRequest));
	}
	/**
	 * @param paymentRequest
	 *           - a CIS payment request with at least the amount and currency set.
	 * @param transactionId
	 *           a transaction id
	 * @param clientAuthorizationId
	 *           the client authorization id
	 * @return simulates a capture and returns the on the request set amount, the ID CAP123 and an accepted decision
	 */
	@Override
	public CisPaymentTransactionResult capture(final CisPaymentRequest paymentRequest, final String transactionId,
			final String clientAuthorizationId)
	{
		return cyberSourceCaptureExecutor.execute(new Pair<String, CisPaymentRequest>(transactionId, paymentRequest));
	}

	/**
	 * @param paymentRequest
	 *           - a CIS payment request with at least the amount and currency set.
	 * @param transactionId
	 *           a transaction id
	 * @param clientAuthorizationId
	 *           the client authorization id
	 * @return simulates a refund and returns the on the request set amount, the ID REF123 and an accepted decision
	 */
	@Override
	public CisPaymentTransactionResult refund(final CisPaymentRequest paymentRequest, final String transactionId,
			final String clientAuthorizationId)
	{
		return cyberSourceRefundExecutor.execute(new Pair <String, CisPaymentRequest>(transactionId, paymentRequest));
	}

	/**
	 * @param authorization
	 *           an external authorization request, e.g. with provided information by CyberSource SOP
	 * @return returns based on the decision and parameters (order nr, request id, verificationsignature,
	 *         ccAuthReply_amount, ccAuthReply_accountBalance) a authorization.
	 */
	@Override
	public CisPaymentTransactionResult handleExternalAuthorization(final CisExternalPaymentRequest authorization)
	{
		
		boolean checkPayerAuth = false;
		boolean checkPayerValidate = false;
    	
    	CisPaymentTransactionResult result = null;
    	
    	
   		Map<String, String> map = authorization.getParameters().getMap();
   	
		LOG.info("ORIGINAL MAP IS  : " + map);
		checkPayerAuth = (map.get("checkPayerAuth") != null && "true".equals( map.get("checkPayerAuth"))) ? true : false;
		checkPayerValidate = (map.get("checkPayerValidate") != null && "true".equals( map.get("checkPayerValidate"))) ? true : false;

		String profileId = map.get("profileId");
		CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization ();
		paymentRequest.setParameters(new AnnotationHashMap(map));
		paymentRequest.setClientAuthorizationId(map.get("clientAuthorizationId"));
		
		paymentRequest.setAmount(new BigDecimal(map.get("amount")));
		paymentRequest.setCurrency(map.get("currency"));
		
		LOG.info("LOG paymentRequest");
		CSUtil.log(LOG, paymentRequest);
		LOG.info("LOG paymentRequest parameters");
		CSUtil.log(LOG, paymentRequest.getParameters());
		
    	LOG.info("checkPayerAuth: " + checkPayerAuth);
    	LOG.info("checkPayerValidate: " + checkPayerValidate);
    	if (checkPayerAuth) {
        	result = cyberSourcePayerAuthExecutor.execute(new Pair <String, CisPaymentAuthorization>(profileId, paymentRequest));
        	if ("475".equals(result.getVendorReasonCode())){
        		LOG.info("return cyberSourcePayerAuthExecutor " );
        		CSUtil.log(LOG, result);
        		return result;
        	}
    	}
    	else if (checkPayerValidate) {
    		result = cyberSourcePayerAuthValidateExecutor.execute(new Pair <String, CisPaymentAuthorization>(profileId, paymentRequest));
    		if ("100".equals(result.getVendorReasonCode()) || "476".equals(result.getVendorReasonCode())){
    	 		LOG.info("return cyberSourcePayerAuthValidateExecutor " );
        		CSUtil.log(LOG, result);
        		return result;
        	}
    	}
    	
    	if (checkPayerAuth) {
    		map.putAll(result.getVendorResponses().getMap());
    		paymentRequest.setParameters(new AnnotationHashMap(map));
    	}
   	
    	result = cyberSourceAuthorizeWithProfileExecutor.execute(new Pair <String, CisPaymentAuthorization>(profileId, paymentRequest));
    	CSUtil.log(LOG, result);
        return result;

	}

	/**
	 * @param profile
	 *           CisExternalPaymentRequest with data e.g. from Cybersource SOP
	 * @return CisPaymentProfileResult with the amount from the request, the decision accept, and id
	 */
	@Override
	public CisPaymentProfileResult handleExternalProfile(final CisExternalPaymentRequest profile)
	{
		return this.cyberSourceResponseHandler.handleProfileResponse(profile);
	}

	/**
	 * @param profileId
	 *           the id of the profile to delete
	 * @result CisPaymentProfileResult with an ACCEPT to indicate it was successfully deleted
	 */
	@Override
	public CisPaymentProfileResult deleteCustomerProfile(final String profileId)
	{
		return cyberSourceDeleteProfileExecutor.execute(profileId);
	}

	/**
	 * @param request
	 *           CisPaymentProfileRequest a profile request
	 * @return CisPaymentProfileResult with the decision accept
	 */
	@Override
	public CisPaymentProfileResult updateCustomerProfile(final CisPaymentProfileRequest request)
	{
		return cyberSourceUpdateProfileExecutor.execute(request);
	}

	@Override
	public String getHpfUrl()
	{
		return hpfUrl;
	}

	public void setHpfUrl(final String hpfUrl)
	{
		this.hpfUrl = hpfUrl;
	}

	/**
	 * @param paymentRequest
	 *           a payment session init request for tokenized payments
	 * @result CisTokenizedPaymentTransactionResult an accepted payment with id 123456
	 */
	@Override
	public CisTokenizedPaymentTransactionResult initPaymentSession(final CisPaymentSessionInitRequest paymentRequest)
	{
		throw new ServiceNotImplementedException( "initPaymentSession" );
	}

	/**
	 * @param paymentRequest
	 *           a tokenized payment session authorization request
	 * @result CisTokenizedPaymentTransaction Result - a tokenized transaction result with the decision accept, the id
	 *         123456, the request token "TTTTTTTTTTTTTTTTTTTT" and the id "O-68K784427J893111J"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult setupAuthorizationGroup(final CisTokenizedPaymentAuthorization paymentRequest)
	{
		throw new ServiceNotImplementedException( "setupAuthorizationGroup" );
	}

	/**
	 * @param paymentRequest
	 *           a tokenized payment authorization
	 * @param authorizationId
	 *           the authorization id
	 * @result CisTokenizedPaymentTransactionResult - a tokenized transaction result which got accepted, with the request
	 *         id "3427089744160176056428", the request token "zAmB5An7EliJgekCMciZhk0kyro9JselIuchJLWecFZiWAAAA9gWN" and
	 *         the id "90R12860324048315"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult authorizeOnGroup(final CisTokenizedPaymentAuthorization paymentRequest,
			final String authorizationId)
	{
		throw new ServiceNotImplementedException( "authorizeOnGroup" );
	}

	/**
	 * @param paymentRequest
	 *           a tokenized payment capture request
	 * @param authorizationId
	 *           the authorizationId to be used for the capture
	 * @result CisTokenizedPaymentTransactionResult a capture which got accepted with the request id "34859030969079228",
	 *         the token id "AhjrrwSRc5DZOaDHQ1DYap+zAmB5An7EliJgekCMcaslkdfjoieIuchJLWecFZiWAAAA9gWN;
	 *         ", the id "1H993482W00985358"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult capture(final CisTokenizedPaymentCapture paymentRequest,
			final String authorizationId) {
		return cyberSourceTokenizedCaptureExecutor.execute(new Pair<String, CisPaymentRequest>(authorizationId, paymentRequest));
	}

	/**
	 * @param paymentRequest
	 *           a payment refund request and
	 * @param captureId
	 *           the captureId where the refund should be done on
	 * @result CisTokenizedPaymentTransactionResult - an accepted refund with the request id "3428159770920176056442",
	 *         the request token "AhjrrwSRc66MOPdLL/D0ap+vSLuFmn61r5VUOkB8ZE1DJpJlXR6TY9KRc656H8N1fmjYAAAA+wOa", and the
	 *         id "6A606551MX315692V"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult refund(final CisTokenizedPaymentRefund paymentRequest, final String captureId)
	{
		return cyberSourceTokenizedRefundExecutor.execute(new Pair<String, CisPaymentRequest>(captureId, paymentRequest));
	}

	/**
	 * @param paymentRequest
	 *           a tokenized payment reversal request
	 * @param authorizationId
	 *           the authorizationid of the authorization to be reversed
	 * @result CisTokenizedPaymentResult - an accepted reversal with requestId "3430661984840176056470", and request
	 *         token "AhjrrwSRc/P/hZJmdnEsap+2v5q5Cn7EpGEbukACJ2GTSTKuj0mx6Ui5+fDARVeQ9JYA3wyA"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult reverse(final CisTokenizedPaymentReverse paymentRequest,
			final String authorizationId)
	{
		return cyberSourceTokenizedReverseExecutor.execute(new Pair<String, CisPaymentRequest> (authorizationId, paymentRequest));
	}

	/**
	 * @param paymentRequest
	 *           a tokenized payment reversal
	 * @param authorizationGroupId
	 *           a authorization group id to do the reversal on
	 * @result CisTokenizedPaymentTransactionResult an accepted reversal with the request id "3430661984840176056470",
	 *         and the request token "AhjrrwSRc/P/hZJmdnEsap+2v5q5Cn7EpGEbukACJ2GTSTKuj0mx6Ui5+fDARVeQ9JYA3wyA"
	 */
	@Override
	public CisTokenizedPaymentTransactionResult reverseAuthorizationGroup(final CisTokenizedPaymentReverse paymentRequest,
			final String authorizationGroupId)
	{
		throw new ServiceNotImplementedException( "authorizeOnGroup" );
	}

	@Override
	public CisResult testConnection()
	{
		throw new ServiceNotImplementedException( "testConnection" );
	}


}
