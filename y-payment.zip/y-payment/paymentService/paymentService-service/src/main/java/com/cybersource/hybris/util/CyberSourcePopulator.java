package com.cybersource.hybris.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.cybersource.stub.BillTo;
import com.cybersource.stub.Card;
import com.cybersource.stub.Item;
import com.cybersource.stub.PurchaseTotals;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.ShipTo;
import com.hybris.cis.api.model.CisAddress;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisCreditCard;
import com.hybris.cis.api.payment.model.CisPaymentRequest;
import com.hybris.cis.common.utils.StringUtils;

public class CyberSourcePopulator {

	/**
	 * 
	 * @param address
	 * @return
	 */
	public static BillTo convertBillToAddress(final CisAddress address) {

		final BillTo billTo = new BillTo();

		if (address != null) {
			billTo.setFirstName(address.getFirstName());
			billTo.setLastName(address.getLastName());
			billTo.setEmail(address.getEmail());
			billTo.setStreet1(address.getAddressLine1());
			if (StringUtils.isNotBlank(address.getAddressLine2())) {
				billTo.setStreet2(address.getAddressLine2());
			}
			billTo.setCity(address.getCity());
			billTo.setState(address.getState());
			billTo.setPostalCode(address.getZipCode());
			billTo.setCountry(address.getCountry());
		}

		return billTo;
	}

	/**
	 * 
	 * @param address
	 * @return
	 */
	public static ShipTo convertShipToAddress(final CisAddress address) {

		final ShipTo shipTo = new ShipTo();

		if (address != null) {
			shipTo.setFirstName(address.getFirstName());
			shipTo.setLastName(address.getLastName());
			shipTo.setEmail(address.getEmail());
			shipTo.setStreet1(address.getAddressLine1());
			if (StringUtils.isNotBlank(address.getAddressLine2())) {
				shipTo.setStreet2(address.getAddressLine2());
			}
			shipTo.setCity(address.getCity());
			shipTo.setState(address.getState());
			shipTo.setPostalCode(address.getZipCode());
			shipTo.setCountry(address.getCountry());
		}

		return shipTo;
	}

	/**
	 * 
	 * @param payment
	 * @return
	 */
	public static PurchaseTotals getPurchaseTotal(
			final CisPaymentRequest payment) {
		final PurchaseTotals purchaseTotal = new PurchaseTotals();

		// Set currency
		purchaseTotal.setCurrency(payment.getCurrency());

		// Set grand total amount
		if (payment.getAmount() != null) {
			purchaseTotal.setGrandTotalAmount(payment.getAmount().toString());
		}

		return purchaseTotal;
	}

	/**
	 * 
	 * @param cisCreditCard
	 * @return
	 */
	public static Card convertCardInfo(final CisCreditCard cisCreditCard) {
		final Card card = new Card();

		if (cisCreditCard != null) {
			card.setAccountNumber(cisCreditCard.getCcNumber());
			card.setExpirationMonth(BigInteger.valueOf(cisCreditCard
					.getExpirationMonth()));
			card.setExpirationYear(BigInteger.valueOf(cisCreditCard
					.getExpirationYear()));
			card.setCardType(cisCreditCard.getCardType());
			card.setCvNumber(cisCreditCard.getCvc());
			card.setFullName(cisCreditCard.getCardHolder());
		}
		return card;
	}

	public static CisDecision convertToCisDecision(String vendorDecision) {
		if (CyberSourceConstant.ACCEPT.equals(vendorDecision)) {
			return CisDecision.ACCEPT;
		} else if (CyberSourceConstant.REJECT.equals(vendorDecision)) {
			return CisDecision.REJECT;
		} else if (CyberSourceConstant.REVIEW.equals(vendorDecision)) {
			return CisDecision.REVIEW;
		} else
			return CisDecision.ERROR;
	}

	public static BillTo convertBillToAddress(Map<String, String> params) {

		final BillTo billTo = new BillTo();

		if (params != null) {
			billTo.setFirstName(params.get("billTo_firstName"));
			billTo.setLastName(params.get("billTo_lastName"));
			billTo.setEmail(params.get("billTo_email"));
			billTo.setStreet1(params.get("billTo_street1"));
			if (StringUtils.isNotBlank(params.get("billTo_street2"))) {
				billTo.setStreet2(params.get("billTo_street2"));
			}
			billTo.setCity(params.get("billTo_city"));
			billTo.setState(params.get("billTo_state"));
			billTo.setPostalCode(params.get("billTo_postalCode"));
			billTo.setCountry(params.get("billTo_country"));
			billTo.setIpAddress(params.get("billTo_ipAddress"));
			billTo.setPhoneNumber(params.get("billTo_phoneNumber"));
//			if (params.get("billTo_customerID") != null) {
//				billTo.setCustomerID(params.get("billTo_customerID"));				
//			}
		}

		return billTo;
	}

	public static ShipTo convertShipToAddress(Map<String, String> params) {

		final ShipTo shipTo = new ShipTo();

		if (params != null) {
			shipTo.setFirstName(params.get("shipTo_firstName"));
			shipTo.setLastName(params.get("shipTo_lastName"));
			shipTo.setEmail(params.get("shipTo_email"));
			shipTo.setStreet1(params.get("shipTo_street1"));
			if (StringUtils.isNotBlank(params.get("shipTo_street2"))) {
				shipTo.setStreet2(params.get("shipTo_street2"));
			}
			shipTo.setCity(params.get("shipTo_city"));
			shipTo.setState(params.get("shipTo_state"));
			shipTo.setPostalCode(params.get("shipTo_postalCode"));
			shipTo.setCountry(params.get("shipTo_country"));
			shipTo.setPhoneNumber(params.get("shipTo_phoneNumber"));
			shipTo.setShippingMethod(params.get("shipTo_shippingMethod"));
		}

		return shipTo;
	}

	public static Map<String, String> prepareErrorFields(
			final ReplyMessage vendorSpecificResponse) {
		final Map<String, String> errorFields = new HashMap<String, String>();

		for (final String invalidField : vendorSpecificResponse
				.getInvalidFields()) {
			errorFields.put(CyberSourceConstant.INVALID_FIELD + invalidField,
					invalidField);
		}

		for (final String missingField : vendorSpecificResponse
				.getMissingFields()) {
			errorFields.put(CyberSourceConstant.MISSING_FIELD + missingField,
					missingField);
		}

		if (CollectionUtils.isEmpty(errorFields)) {
			errorFields.put(CyberSourceConstant.INVALID_FIELD,
					"Unknown invalid or missing field. The ID might be wrong.");
		}
		return errorFields;
	}

	public static Item[] convertItems(Map<String, String> params) {

		int i = 0;
		List<Item> itemList = new ArrayList<Item>();
		String max_number = params.get("items_max_quantity");
		if (max_number != null) {
			int max = Integer.parseInt(params.get("items_max_quantity"));

			while (i < max) {
				i++;
				final Item item = new Item();
				item.setId(BigInteger.valueOf(i));
				item.setUnitPrice(params.get("item_" + i + "_unitPrice"));
				item.setProductSKU(params.get("item_" + i + "_productSKU"));
				item.setProductCode(params.get("item_" + i + "_productCode"));
				item.setProductName(params.get("item_" + i + "_productName"));
				item.setQuantity(new BigInteger(params.get("item_" + i
						+ "_quantity")));
				itemList.add(item);
			}
			return itemList.toArray(new Item[max]);
		}
		return null;
	}

}
