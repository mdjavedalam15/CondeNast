/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.cybersource.hybris.payment.executor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import com.cybersource.stub.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.cybersource.hybris.util.CSUtil;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.common.utils.StringUtils;
import com.hybris.cis.common.utils.SubscriptionServiceData;

/**
 * 
 */
public class CyberSourceAuthorizeWithProfileExecutor
		extends
		AbstractSimpleServiceMethodExecutor<Pair<String, CisPaymentAuthorization>, CisPaymentTransactionResult, RequestMessage, ReplyMessage> {

	private static final Logger LOG = LoggerFactory
			.getLogger(CyberSourceAuthorizeWithProfileExecutor.class);

	@Resource
	SubscriptionServiceData subscriptionServiceData;

	@Resource
	WebServiceClient webServiceClient;

	@Resource
	CyberSourceErrorHandler cyberSourceErrorHandler;

	 private Properties acceptProperties;
	
	
	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			Pair<String, CisPaymentAuthorization> request) {
		final RequestMessage requestMessage = new RequestMessage();

		final CisPaymentAuthorization paymentRequest = request.getValue();
		
		AnnotationHashMap parameters = paymentRequest.getParameters();
		Map<String, String> map = parameters.getMap();

		
		
		BusinessRules businessRules = new BusinessRules ();
		String ignoreAVSResult = map.get("businessRules_ignoreAVSResult");
		if (ignoreAVSResult != null && !ignoreAVSResult.isEmpty()) {
			businessRules.setIgnoreAVSResult(ignoreAVSResult);
			requestMessage.setBusinessRules(businessRules);
		} else {
			LOG.error("Could not get ignore avs result, value of variable is: " + ignoreAVSResult);
		}

		String ignoreCVResult = map.get("businessRules_ignoreCVResult");
		if (ignoreCVResult != null && !ignoreCVResult.isEmpty()) {
			businessRules.setIgnoreCVResult(ignoreCVResult);
			requestMessage.setBusinessRules(businessRules);
		} else {
			LOG.error("Could not get ignore avs result, value of variable is: " + ignoreAVSResult);
		}

		String cvNumber = map.get("card_cvn");
		if (cvNumber != null && !cvNumber.isEmpty()) {
			Card card = new Card();
			card.setCvNumber(cvNumber);
			requestMessage.setCard(card);
		}
		else {
			LOG.warn("cvn number in reqeust message is: " + cvNumber);
		}


		// Set subscription ID (profile ID)
		final RecurringSubscriptionInfo recurringSubscriptionInfo = new RecurringSubscriptionInfo();
		recurringSubscriptionInfo.setSubscriptionID(request.getKey());
		requestMessage.setRecurringSubscriptionInfo(recurringSubscriptionInfo);

		// Set value(s) of purchase totals
		requestMessage.setPurchaseTotals(CyberSourcePopulator.getPurchaseTotal(paymentRequest));
		
		requestMessage.setBillTo(CyberSourcePopulator.convertBillToAddress(map));
		requestMessage.setShipTo(CyberSourcePopulator.convertShipToAddress(map));
		final Item[] items = CyberSourcePopulator.convertItems(map);
		if (items != null) {
			for (Item item : items) {
				requestMessage.getItems().add(item);			
			}
			
		}
	
		// Indicate that it's an authorize request
		final CCAuthService ccAuthService = new CCAuthService();
		ccAuthService.setRun("true");
		LOG.info("REQUEST MAP IS  : " + map);
		if (map != null) {
		
			if (StringUtils.isNotBlank(map.get("clientAuthorizationId"))) {
				requestMessage.setMerchantReferenceCode(map.get("clientAuthorizationId"));
			}
			
			String deviceFingerPrint = map.get("req_device_fingerprint_id");
			if (StringUtils.isNotBlank(deviceFingerPrint)) {
				LOG.info("SETTING DEVICE : " + deviceFingerPrint);
				requestMessage.setDeviceFingerprintID(deviceFingerPrint);			
			}
			if (StringUtils.isNotBlank(map.get("paresStatus"))) {
				ccAuthService.setParesStatus(map.get("paresStatus"));
			}
			if (StringUtils.isNotBlank(map.get("xid"))) {
				ccAuthService.setXid(map.get("xid"));	
			}
			if (StringUtils.isNotBlank(map.get("commerceIndicator"))) {
				ccAuthService.setCommerceIndicator(map.get("commerceIndicator"));
			}
			if (StringUtils.isNotBlank(map.get("eciRaw"))) {
				ccAuthService.setEciRaw(map.get("eciRaw"));
			}
			if (StringUtils.isNotBlank(map.get("cavv"))) {
				ccAuthService.setCavv(map.get("cavv"));
			}
			if (StringUtils.isNotBlank(map.get("cavvAlgorithm"))) {
				ccAuthService.setCavvAlgorithm(map.get("cavvAlgorithm"));
			}
			UCAF ucaf = new UCAF();
			boolean setUsaf = false;
			if (StringUtils.isNotBlank(map.get("ucafCollectionIndicator"))) {
				ucaf.setCollectionIndicator(map.get("ucafCollectionIndicator"));
				setUsaf = true;
			}
			if (StringUtils.isNotBlank(map.get("ucafAuthenticationData"))) {
				ucaf.setAuthenticationData(map.get("ucafAuthenticationData"));
				setUsaf = true;
			}
			if (setUsaf) {
				requestMessage.setUcaf(ucaf);
			}
			if (StringUtils.isNotBlank(map.get("veresEnrolled"))) {
				ccAuthService.setVeresEnrolled(map.get("veresEnrolled"));
			}
		}
	
		requestMessage.setCcAuthService(ccAuthService);
		CSUtil.log(LOG, requestMessage);
		CSUtil.log(LOG, requestMessage.getCard());
		CSUtil.log(LOG, requestMessage.getBusinessRules());
		CSUtil.log(LOG, requestMessage.getItems());
		CSUtil.log(LOG, requestMessage.getCcAuthService());
		CSUtil.log(LOG, requestMessage.getUcaf());
		CSUtil.log(LOG, requestMessage.getCcAuthService());
		return requestMessage;
	}

	@Override
	protected CisPaymentTransactionResult convertResponse(
			Pair<String, CisPaymentAuthorization> request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisPaymentTransactionResult cisResult = new CisPaymentTransactionResult();
		
	//	CSUtil.log(LOG, replyMessage, replyMessage.getCcAuthReply(), replyMessage.getDecisionReply());
		
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));
		List <String> codeList = getCodesListFromString(acceptProperties.getProperty("cybersource.createorderandflag.codes"));
		CSUtil.log(LOG, codeList);
		if (CisDecision.REJECT.equals(cisResult.getDecision()) || codeList.contains(String.valueOf(replyMessage.getReasonCode()))) {
			replyMessage.setDecision("ACCEPT");
			cisResult.setDecision(CisDecision.ACCEPT);	
		}
		else if (CisDecision.REJECT.equals(cisResult.getDecision())) {
			cyberSourceErrorHandler.determineErrorCodes(
					CyberSourcePopulator.prepareErrorFields(replyMessage),
					replyMessage.getReasonCode().toString());
		}
		CisPaymentAuthorization requestOrig = request.getValue();
		
		cisResult.setId(replyMessage.getRequestID());
		cisResult.setRequest(request.getValue());
		cisResult.setVendorReasonCode(String.valueOf(replyMessage.getReasonCode()));
		cisResult.setClientAuthorizationId(requestOrig.getClientAuthorizationId());
	
		
		Map <String, String> map = new HashMap<String, String>();
		
		CCAuthReply ccAuthReply = replyMessage.getCcAuthReply();
		
		
		if (StringUtils.isNotBlank(replyMessage.getRequestID())) {
			map.put("requestID", replyMessage.getRequestID());
		}
		if (StringUtils.isNotBlank(replyMessage.getDecision())) {
			map.put("decision", replyMessage.getDecision());
		}
		if (StringUtils.isNotBlank(String.valueOf(replyMessage.getReasonCode()))) {
			map.put("reasonCode", String.valueOf(replyMessage.getReasonCode()));
		}
		
		if (StringUtils.isNotBlank(ccAuthReply.getAuthorizationCode())) {
			map.put("authorizationCode", ccAuthReply.getAuthorizationCode());
		}
		if (StringUtils.isNotBlank(ccAuthReply.getAvsCode())) {
			map.put("avsCode", ccAuthReply.getAvsCode());
		}
		cisResult.setVendorResponses(new AnnotationHashMap(map));
		if (replyMessage.getCcAuthReply() != null
				&& replyMessage.getCcAuthReply().getAmount() != null) {
			cisResult.setAmount(new BigDecimal(replyMessage.getCcAuthReply()
					.getAmount()));
		}
		if (replyMessage.getCcAuthReply() != null
				&& replyMessage.getCcAuthReply().getAccountBalance() != null) {
			cisResult.setBalance(new BigDecimal(replyMessage.getCcAuthReply()
					.getAccountBalance()));
		}
		
		return cisResult;
	}

	public Properties getAcceptProperties() {
		return acceptProperties;
	}

	public void setAcceptProperties(Properties acceptProperties) {
		this.acceptProperties = acceptProperties;
	}
	
	private List<String> getCodesListFromString(String source) {
		source = source.replaceAll(" ", "");
		String[] acceptCodesArray = source.split(",");
		return new ArrayList<String>(Arrays.asList(acceptCodesArray));
	}

}
