package com.cybersource.hybris.payment.executor;

import java.math.BigDecimal;

import javax.annotation.Resource;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.cybersource.stub.CCCreditService;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.common.utils.StringUtils;

public class CyberSourceRefundExecutor
		extends
		AbstractSimpleServiceMethodExecutor<Pair<String, CisPaymentRequest>, CisPaymentTransactionResult, RequestMessage, ReplyMessage> {
	@Resource
	WebServiceClient webServiceClient;

	@Resource
	CyberSourceErrorHandler cyberSourceErrorHandler;

	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			final Pair<String, CisPaymentRequest> paymentRequest) {
		final RequestMessage requestMessage = new RequestMessage();

		// Set value(s) of purchase totals.
		requestMessage.setPurchaseTotals(CyberSourcePopulator
				.getPurchaseTotal(paymentRequest.getValue()));

		// Indicate that it's a refund request
		final CCCreditService ccCreditService = new CCCreditService();
		StringUtils.checkPrecondition(paymentRequest.getKey(), "transactionId");

		ccCreditService.setCaptureRequestID(paymentRequest.getKey());
		ccCreditService.setRun("true");
		requestMessage.setCcCreditService(ccCreditService);

		return requestMessage;
	}

	@Override
	protected CisPaymentTransactionResult convertResponse(
			final Pair<String, CisPaymentRequest> request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisPaymentTransactionResult cisResult = new CisPaymentTransactionResult();
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));

		if (CisDecision.REJECT.equals(cisResult.getDecision())) {
			cyberSourceErrorHandler.determineErrorCodes(
					CyberSourcePopulator.prepareErrorFields(replyMessage),
					replyMessage.getReasonCode().toString());
		}

		cisResult.setRequest(request.getValue());
		if (replyMessage.getCcCreditReply() != null
				&& replyMessage.getCcCreditReply().getAmount() != null) {
			cisResult.setAmount(new BigDecimal(replyMessage.getCcCreditReply()
					.getAmount()));
		}

		return cisResult;
	}

}