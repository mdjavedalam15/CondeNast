package com.cybersource.hybris.payment.executor;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.util.CSUtil;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.cybersource.stub.PaySubscriptionUpdateService;
import com.cybersource.stub.RecurringSubscriptionInfo;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.api.exception.InvalidOrMissingFieldException;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisPaymentProfileRequest;
import com.hybris.cis.api.payment.model.CisPaymentProfileResult;
import com.hybris.cis.common.utils.StringUtils;
import com.hybris.cis.common.utils.SubscriptionServiceData;

public class CyberSourceUpdateProfileExecutor

		extends
		AbstractSimpleServiceMethodExecutor<CisPaymentProfileRequest, CisPaymentProfileResult, RequestMessage, ReplyMessage> {

	private static final Logger LOG = LoggerFactory
			.getLogger(CyberSourceUpdateProfileExecutor.class);

	@Resource
	WebServiceClient webServiceClient;

	@Resource
	SubscriptionServiceData subscriptionServiceData;

	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			final CisPaymentProfileRequest request) {
		final RequestMessage requestMessage = new RequestMessage();

		// Indicate that it's a update customer profile request
		final PaySubscriptionUpdateService paySubscriptionUpdateService = new PaySubscriptionUpdateService();
		paySubscriptionUpdateService.setRun("true");
		requestMessage
				.setPaySubscriptionUpdateService(paySubscriptionUpdateService);
		// Set profile id
		final RecurringSubscriptionInfo recurringSubscriptionInfo = new RecurringSubscriptionInfo();
		recurringSubscriptionInfo.setSubscriptionID(request.getProfileId());

		// Set card info
		if (request.getCreditCard() != null
				&& StringUtils
						.isNotBlank(request.getCreditCard().getCcNumber())) {
			throw new InvalidOrMissingFieldException(
					"Can NOT update credit card number for customer profile!");
		}
		requestMessage.setCard(CyberSourcePopulator.convertCardInfo(request
				.getCreditCard()));

		// Set the BillTo address
		requestMessage.setBillTo(CyberSourcePopulator
				.convertBillToAddress(request.getBillingAddress()));

		// Set the ShipTo address
		requestMessage.setShipTo(CyberSourcePopulator
				.convertShipToAddress(request.getShippingAddress()));

		requestMessage.setRecurringSubscriptionInfo(recurringSubscriptionInfo);

		return requestMessage;
	}

	@Override
	protected CisPaymentProfileResult convertResponse(
			final CisPaymentProfileRequest request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisPaymentProfileResult cisResult = new CisPaymentProfileResult();
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));

		if (CisDecision.REJECT.equals(cisResult.getDecision())
				|| CisDecision.ERROR.equals(cisResult.getDecision())) {
			CSUtil.log(LOG, requestMessage, replyMessage);
		}

		return cisResult;
	}

}
