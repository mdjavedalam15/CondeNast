/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.cybersource.hybris.payment.executor;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.cybersource.hybris.util.CSUtil;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.cybersource.stub.PayerAuthValidateReply;
import com.cybersource.stub.PayerAuthValidateService;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.common.utils.StringUtils;
import com.hybris.cis.common.utils.SubscriptionServiceData;

/**
 * 
 */
public class CyberSourcePayerAuthValidateExecutor
		extends
		AbstractSimpleServiceMethodExecutor<Pair<String, CisPaymentAuthorization>, CisPaymentTransactionResult, RequestMessage, ReplyMessage> {

	private static final Logger LOG = LoggerFactory
			.getLogger(CyberSourcePayerAuthValidateExecutor.class);

	@Resource
	SubscriptionServiceData subscriptionServiceData;

	@Resource
	WebServiceClient webServiceClient;

	@Resource
	CyberSourceErrorHandler cyberSourceErrorHandler;

	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			Pair<String, CisPaymentAuthorization> request) {
		final RequestMessage requestMessage = new RequestMessage();

		final CisPaymentAuthorization paymentRequest = request.getValue();

		// // Set subscription ID (profile ID)
		// final RecurringSubscriptionInfo recurringSubscriptionInfo = new
		// RecurringSubscriptionInfo();
		// recurringSubscriptionInfo.setSubscriptionID(request.getKey());
		// requestMessage.setRecurringSubscriptionInfo(recurringSubscriptionInfo);
		//
		// // Set value(s) of purchase totals
		// requestMessage.setPurchaseTotals(CyberSourcePopulator
		// .getPurchaseTotal(paymentRequest));

		requestMessage.setPayerAuthValidateService(new PayerAuthValidateService());
		requestMessage.getPayerAuthValidateService().setRun("true");

		AnnotationHashMap parameters = paymentRequest.getParameters();
		Map<String, String> map = parameters.getMap();
		
		requestMessage.setMerchantReferenceCode(paymentRequest.getClientAuthorizationId());

		if (map != null) {
			String paRes = map.get("PaRes");
			if (StringUtils.isNotBlank(paRes)) {
				requestMessage.getPayerAuthValidateService().setSignedPARes(
						paRes);
			}
			if (StringUtils.isNotBlank(map.get("clientAuthorizationId"))) {
				requestMessage.setMerchantReferenceCode(map.get("clientAuthorizationId"));
			}
			
			String deviceFingerPrint = map.get("req_device_fingerprint_id");
			if (StringUtils.isNotBlank(deviceFingerPrint)) {
				requestMessage.setDeviceFingerprintID(deviceFingerPrint);			
			}
		}

		return requestMessage;
	}

	@Override
	protected CisPaymentTransactionResult convertResponse(
			Pair<String, CisPaymentAuthorization> request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisPaymentTransactionResult cisResult = new CisPaymentTransactionResult();

		
		CSUtil.log(LOG, replyMessage, replyMessage.getPayerAuthValidateReply());
		
		
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));

		if (CisDecision.REJECT.equals(cisResult.getDecision()) && "476".equals(String.valueOf(replyMessage.getReasonCode()))) {
			cisResult.setDecision(CisDecision.ACCEPT);	
		}
		else if (CisDecision.REJECT.equals(cisResult.getDecision())) {
			cyberSourceErrorHandler.determineErrorCodes(
					CyberSourcePopulator.prepareErrorFields(replyMessage),
					replyMessage.getReasonCode().toString());
		}

		CisPaymentAuthorization requestOrig = request.getValue();
		cisResult.setRequest(request.getValue());
		cisResult.setId(replyMessage.getRequestID());

		cisResult.setClientAuthorizationId(requestOrig
				.getClientAuthorizationId());
		cisResult.setAmount(requestOrig.getAmount());

		cisResult.setVendorReasonCode(String.valueOf(replyMessage
				.getReasonCode()));
		
		
		Map <String, String> map = new HashMap<String, String>();
		
		PayerAuthValidateReply payerAuthValidateReply = replyMessage.getPayerAuthValidateReply();
		if (StringUtils.isNotBlank(payerAuthValidateReply.getParesStatus())) {
			map.put("paresStatus", payerAuthValidateReply.getParesStatus());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getXid())) {
			map.put("xid", payerAuthValidateReply.getXid());	
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getCommerceIndicator())) {
			map.put("commerceIndicator", payerAuthValidateReply.getCommerceIndicator());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getEci())) {
			map.put("eci", payerAuthValidateReply.getEci());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getEciRaw())) {
				map.put("eciRaw", payerAuthValidateReply.getEciRaw());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getCavv())) {
				map.put("cavv", payerAuthValidateReply.getCavv());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getCavvAlgorithm())) {
			map.put("cavvAlgorithm", payerAuthValidateReply.getCavvAlgorithm());
		}
		
		if (StringUtils.isNotBlank(payerAuthValidateReply.getUcafCollectionIndicator())) {
				map.put("ucafCollectionIndicator", payerAuthValidateReply.getUcafCollectionIndicator());
		}
		if (StringUtils.isNotBlank(payerAuthValidateReply.getUcafAuthenticationData())) {
			map.put("ucafAuthenticationData", payerAuthValidateReply.getUcafAuthenticationData());
		}
	
		cisResult.setVendorResponses(new AnnotationHashMap(map));

		
		return cisResult;
	}

}
