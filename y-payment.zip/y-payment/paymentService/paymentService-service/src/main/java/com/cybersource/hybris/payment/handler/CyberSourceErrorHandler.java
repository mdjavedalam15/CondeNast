/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.cybersource.hybris.payment.handler;

import com.hybris.cis.api.exception.NotFoundException;
import com.hybris.cis.api.exception.ServiceErrorResponseException;
import com.hybris.cis.api.exception.ServiceRequestException;
import com.hybris.cis.api.exception.codes.ServiceExceptionDetail;
import com.hybris.cis.api.exception.codes.UnknownServiceExceptionDetail;
import com.hybris.cis.api.payment.exception.PaymentServiceExceptionCodes;
import org.springframework.beans.factory.annotation.Required;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;


public class CyberSourceErrorHandler
{
    private Properties errorCodeProperties;

	public void determineErrorCodes(final Map<String, String> missingOrInvalidFields, final String reasonCode)
	{

		// Don't care if it's missing or invalid
		if ("101".equals(reasonCode) || "102".equals(reasonCode))
		{
			handleInvalidFields(missingOrInvalidFields, reasonCode);
		}
		// special handling for general card declined
		else if ("203".equals(reasonCode)) // card Number
		{
			throw new ServiceRequestException(new ServiceExceptionDetail(PaymentServiceExceptionCodes.GENERAL_DECLINE_OF_CARD));
		}
		// special handling for api calls
		else if ("231".equals(reasonCode)) // card Number
		{
			throw new ServiceRequestException(new ServiceExceptionDetail(PaymentServiceExceptionCodes.CARD_ACCOUNTNUMBER_INVALID));
		}
		else if ("235".equals(reasonCode)) // invalid capture amount
		{
			throw new ServiceRequestException(new ServiceExceptionDetail(PaymentServiceExceptionCodes.AMOUNT_INVALID));
		}
		else if ("243".equals(reasonCode)) // The transaction has already been settled or reversed.
		{
			throw new NotFoundException("unknown", reasonCode);
		}
		else if (!getErrorCodeProperties().containsKey(reasonCode)) // The transaction has already been settled or reversed.
		{
			throw new NotFoundException("unknown", reasonCode);
		}
		else
		{
			throw new ServiceErrorResponseException(new UnknownServiceExceptionDetail(reasonCode));
		}
	}

	/**
	 * This method handles missing and invalid fields. Depending on the request, cybersource returns different
	 * kind of answers. Therefore, this method checks on a string comparison basis which error occured and maps
	 * it to a PaymentServiceExceptionCode
	 * 
	 * @param responseMap the map received by the request\
	 * @param reasonCode the reason code returned by Cybersource
	 */
	private void handleInvalidFields(final Map<String, String> responseMap, final String reasonCode)
	{
		final List<ServiceExceptionDetail> exceptionCodes = new ArrayList<ServiceExceptionDetail>();
		final ServiceExceptionDetail cardDateInvalid = new ServiceExceptionDetail(
				PaymentServiceExceptionCodes.CARD_EXP_DATE_INVALID);
		final ServiceExceptionDetail billingAddressInvalid = new ServiceExceptionDetail(
				PaymentServiceExceptionCodes.INVALID_BILLING_ADDRESS);
		for (final Entry<String, String> entry : responseMap.entrySet())
		{
			final String value = entry.getValue();
			if (entry.getKey().startsWith("MissingField") || entry.getKey().startsWith("InvalidField"))
			{
				if ("card_accountNumber".equals(value) || "c:card/c:accountNumber".equals(value))
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.CARD_ACCOUNTNUMBER_INVALID));
				}
				else if ("card_cardType".equals(value) || "c:cardType".equals(value))
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.CARD_TYPE_INVALID));
				}
				else if (("card_expirationMonth".equals(value) || "c:expirationMonth".equals(value)
						|| "card_expirationYear".equals(value) || "c:expirationYear".equals(value)))
				{
					if (!exceptionCodes.contains(cardDateInvalid))
					{
						exceptionCodes.add(cardDateInvalid);
					}
				}
				else if ("card_cvNumber".equals(value) || "c:cvNumber".equals(value))
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.CVV_NUMBER_REJECTED));
				}
				else if ("(totalGrand)".equals(value) || "c:item[0]/".equals(value))
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.AMOUNT_INVALID));
				}
				else if ("*/c:paypalCustomerEmail".equals(value))
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.MISSING_CUSTOMER_EMAIL));
				}
				else if (value.startsWith("billTo"))
				{
					if (!exceptionCodes.contains(billingAddressInvalid))
					{
						exceptionCodes.add(billingAddressInvalid);
					}
				}
				else if ("c:authRequestID".equals(value))
				{
					throw new NotFoundException(value, reasonCode);
				}
				else
				{
					exceptionCodes.add(new ServiceExceptionDetail(PaymentServiceExceptionCodes.UNKNOWN_CRITICAL_ERROR, value));
				}
			}
		}

		if (exceptionCodes.isEmpty())
		{
			exceptionCodes.add(new UnknownServiceExceptionDetail("Unknown invalid or missing field. The ID might be wrong."));
		}

		throw new ServiceRequestException(exceptionCodes);
	}


    public Properties getErrorCodeProperties()
    {
        return errorCodeProperties;
    }

    @Required
    public void setErrorCodeProperties(Properties errorCodeProperties)
    {
        this.errorCodeProperties = errorCodeProperties;
    }


}
