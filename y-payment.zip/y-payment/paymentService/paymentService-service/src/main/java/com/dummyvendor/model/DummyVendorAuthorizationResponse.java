/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.dummyvendor.model;

import java.math.BigDecimal;

/**
 * * Representation of a sample vendor specific Address Verification Response DTO.
 */

public class DummyVendorAuthorizationResponse
{
    /**
     * Indicates whether an address was validated, should be reviewed or was rejected.
     */
    private String decision;

    /** ID provided by the client that is unique per authorization (e.g. the shipment, return or order id) */
    private String clientAuthorizationId;

    /**
     * Identifies this result.
     */
    private String requestId;

    /** The amount of the transaction. */
    private BigDecimal amount;

    /** 3 letter ISO 4217 currency code. */
    private String currency;

    /** The client reference ID that was passed in the request header (or 'undefined' if not). */
    private String clientRefId;

    /**
     * @return the decision
     */
    public String getDecision() {
        return decision;
    }

    /** The remaining balance of the given payment method (might be null). */
    private BigDecimal balance;

    /**
     *
     * @param decision address validation decision
     */
    public void setDecision(String decision) {
        this.decision = decision;
    }

	/**
	 * @param decision address validation decision
	 */
	public DummyVendorAuthorizationResponse(final String decision)
	{
		this.decision = decision;
	}

    /**
     *
     * @return
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     *
     * @param requestId
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     *
     * @return the clientAuthorizationId
     */
    public String getClientAuthorizationId() {
        return clientAuthorizationId;
    }

    /**
     *
     * @param clientAuthorizationId the clientAuthorizationId
     */
    public void setClientAuthorizationId(String clientAuthorizationId) {
        this.clientAuthorizationId = clientAuthorizationId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getClientRefId() {
        return clientRefId;
    }

    public void setClientRefId(String clientRefId) {
        this.clientRefId = clientRefId;
    }
}
