package com.cybersource.secureacceptance;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;

import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.hybris.cis.api.exception.InvalidOrMissingFieldException;
import com.hybris.cis.api.exception.ServiceRequestException;
import com.hybris.cis.api.exception.codes.ServiceExceptionDetail;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisAddress;
import com.hybris.cis.api.model.CisCvnDecision;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.exception.PaymentServiceExceptionCodes;
import com.hybris.cis.api.payment.model.CisCreditCard;
import com.hybris.cis.api.payment.model.CisCreditCardAuthorization;
import com.hybris.cis.api.payment.model.CisExternalPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentProfileResult;
import com.hybris.cis.api.payment.model.CisPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.common.utils.StringUtils;
import com.hybris.cis.common.utils.SubscriptionServiceData;

public class CyberSourceResponseHandler {

	private static final String FIELD_AUTH_AMT = "ccAuthReply_amount";
	private static final String FIELD_ORDER_CUR = "orderCurrency";
	private static final String FIELD_REQUEST_ID = "requestID";
	private static final String FIELD_REASONCODE_ID = "reasonCode";
	private static final String FIELD_SUBSCRIPTION_ID = "paySubscriptionCreateReply_subscriptionID";
	private static final String FIELD_ACCOUNT_NUMBER = "card_accountNumber";
	private static final String FIELD_EXPIRATION_YEAR = "card_expirationYear";
	private static final String FIELD_EXPIRATION_MONTH = "card_expirationMonth";
	private static final String FIELD_CC_TYPE = "card_cardType";
	private static final String FIELD_CV_NUM = "card_cvNumber";
	private static final String FIELD_EMAIL = "billTo_email";
	private static final String FIELD_FIRST_NAME = "billTo_firstName";
	private static final String FIELD_LAST_NAME = "billTo_lastName";
	private static final String FIELD_PHONE_NUMBER = "billTo_phoneNumber";
	private static final String FIELD_CITY = "billTo_city";
	private static final String FIELD_POSTAL_CODE = "billTo_postalCode";
	private static final String FIELD_STATE = "billTo_state";
	private static final String FIELD_STREET_1 = "billTo_street1";
	private static final String FIELD_STREET_2 = "billTo_street2";
	private static final String FIELD_COUNTRY = "billTo_country";
	private static final String FIELD_COMMENTS = "comments";
	private static final String FIELD_TRANSACTION_SIGNATURE = "transactionSignature";

	// Vendor specific
	private static final String FIELD_AUTH_CODE = "ccAuthReply_authorizationCode";
	private static final String FIELD_AUTH_DATE = "ccAuthReply_authorizedDateTime";
	private static final String FIELD_AUTH_REASON_CODE = "ccAuthReply_reasonCode";
	private static final String FIELD_AVS_CODE = "ccAuthReply_avsCode";
	private static final String FIELD_TAX_ID = "billTo_companyTaxID";
	private static final String FIELD_SIGNED_FIELDS = "signedFields";
	private static final String FIELD_SUBSCRIPTION_SIGN = "paySubscriptionCreateReply_subscriptionIDPublicSignature";
	private static final String FIELD_DECISION_SIGN = "decision_publicSignature";
	private static final String FIELD_ORDER_NUMBER = "orderNumber";
	private static final String FIELD_ORDER_NUM_SIGN = "orderNumber_publicSignature";
	private static final String FIELD_CVN_CODE = "ccAuthReply_cvCode";

	
	private static final String FIELD_ORDER_ID = "orderNumber";
	private static final String FIELD_DECISION = "decision";
	private static final String FIELD_ORDER_AMT = "orderAmount";

	private Map<String, CisDecision> reasonCodesMapping;
	
	
	private SubscriptionServiceData subscriptionServiceData;

	
    private CyberSourceErrorHandler cyberSourceErrorHandler;

	public CyberSourceResponseHandler()
	{
	}
    
	public CyberSourceResponseHandler(Properties statusCodeProps)
	{
		super();
		this.reasonCodesMapping = new HashMap<String, CisDecision>();

		for (final Entry<Object, Object> entry : statusCodeProps.entrySet())
		{
			this.reasonCodesMapping.put((String) entry.getKey(), CisDecision.valueOf((String) entry.getValue()));
		}
	}

	public CisPaymentProfileResult handleProfileResponse(final CisExternalPaymentRequest profile)
	{
		if (CollectionUtils.isEmpty(profile.getParameters().getMap()))
		{
			throw new InvalidOrMissingFieldException("parameters");
		}

		final CisPaymentProfileResult result = new CisPaymentProfileResult();
		final Map<String, String> parameters = profile.getParameters().getMap();

		final String requestID = parameters.get(FIELD_SUBSCRIPTION_ID);

		final String vendorReasonCode = StringUtils.checkPrecondition(parameters, FIELD_REASONCODE_ID);
		result.setVendorReasonCode(vendorReasonCode);

		final String reasonCode = StringUtils.checkPrecondition(parameters, FIELD_REASONCODE_ID);
		final CisDecision cisDecision = this.reasonCodesMapping.get(reasonCode);
		result.setDecision(cisDecision);

		if (CisDecision.REJECT.equals(cisDecision))
		{
			result.setId(requestID == null ? "" : requestID);
			getCyberSourceErrorHandler().determineErrorCodes(parameters, reasonCode);
		}

		if (StringUtils.isBlank(requestID))
		{
			throw new InvalidOrMissingFieldException(FIELD_SUBSCRIPTION_ID);
		}
		result.setId(requestID);

		if (!"true".equals(parameters.get("VerifyTransactionSignature()")))
		{
			throw new ServiceRequestException(new ServiceExceptionDetail(PaymentServiceExceptionCodes.SIGNATURE_VERIFICATION_FAILED));
		}

		final String amount = StringUtils.checkPrecondition(parameters, FIELD_AUTH_AMT);
		result.setAmount(new BigDecimal(amount));
		final String orderCurrency = StringUtils.checkPrecondition(parameters, FIELD_ORDER_CUR);
		result.setCurrency(orderCurrency);

		// Authorization results
		result.setValidationResult(this.createAuthTransaction(parameters));
		result.setCreditCard(this.getCreditCard(parameters));

		result.setCustomerAddress(this.setAddressInformation(parameters));
		result.setComments(parameters.get(FIELD_COMMENTS));
		final String transactionVerification = StringUtils.checkPrecondition(parameters, FIELD_TRANSACTION_SIGNATURE);
		result.setTransactionVerificationKey(transactionVerification);

		final String cvnCheck = parameters.get(FIELD_CVN_CODE);
		// possible decision codes that cybersource can return:
		// http://www.cybersource.com/developers/develop/cybersource_services/quick_references/cvn_results/
		if (null != cvnCheck)
		{
			result.setCvnDecision("M".equals(cvnCheck) ? CisCvnDecision.ACCEPT : CisCvnDecision.REJECT);
		}

		result.setVendorResponses(this.vendorParameters(parameters));
		return result;
	}
	
	
	public CisPaymentTransactionResult handlePaymentResponse(final CisExternalPaymentRequest authorization)
	{
		if (CollectionUtils.isEmpty(authorization.getParameters().getMap()))
		{
			throw new InvalidOrMissingFieldException("parameters");
		}

		final Map<String, String> parameters = authorization.getParameters().getMap();
		final String reasonCode = StringUtils.checkPrecondition(parameters, FIELD_REASONCODE_ID);
		final CisDecision cisDecision = this.reasonCodesMapping.get(reasonCode);
		if (CisDecision.REJECT.equals(cisDecision))
		{
			cyberSourceErrorHandler.determineErrorCodes(parameters, reasonCode);
		}


		final CisPaymentTransactionResult result = new CisPaymentTransactionResult();

		final String orderId = StringUtils.checkPrecondition(parameters, FIELD_ORDER_ID);
		result.setClientAuthorizationId(orderId);

		final String authorizationId = StringUtils.checkPrecondition(parameters, FIELD_REQUEST_ID);
		result.setId(authorizationId);

		if (!Boolean.valueOf(parameters.get("VerifyTransactionSignature()")))
		{
			throw new ServiceRequestException(new ServiceExceptionDetail(PaymentServiceExceptionCodes.SIGNATURE_VERIFICATION_FAILED));
		}

		final String authAmount = StringUtils.checkPrecondition(parameters, FIELD_AUTH_AMT);
		result.setAmount(new BigDecimal(authAmount));

		final String balance = parameters.get("ccAuthReply_accountBalance");
		if (StringUtils.isNotBlank(balance))
		{
			result.setBalance(new BigDecimal(balance));
		}

		result.setVendorReasonCode(reasonCode);

		final String decision = StringUtils.checkPrecondition(parameters, FIELD_DECISION);
		result.setVendorStatusCode(decision);

		final String transactionVerification = StringUtils.checkPrecondition(parameters, FIELD_TRANSACTION_SIGNATURE);
		result.setTransactionVerificationKey(transactionVerification);

		result.setRequest(this.preparePaymentRequest(parameters));
		result.setDecision(cisDecision);

		return result;
	}

	private CisPaymentRequest preparePaymentRequest(final Map<String, String> parameters)
	{
		final CisCreditCardAuthorization res = new CisCreditCardAuthorization();

		final String orderAmount = StringUtils.checkPrecondition(parameters, FIELD_ORDER_AMT);
		res.setAmount(new BigDecimal(orderAmount));

		final String orderCurrency = StringUtils.checkPrecondition(parameters, FIELD_ORDER_CUR);
		res.setCurrency(orderCurrency);

		return res;
	}

	private AnnotationHashMap vendorParameters(final Map<String, String> parameters)
	{
		final Map<String, String> vendorParameters = new HashMap<String, String>();
		final List<String> vendorSpecificFields = Arrays.asList(FIELD_SIGNED_FIELDS, FIELD_AUTH_DATE, FIELD_AVS_CODE, FIELD_TAX_ID,
				FIELD_SUBSCRIPTION_SIGN, FIELD_DECISION_SIGN, FIELD_ORDER_NUM_SIGN, FIELD_CVN_CODE);

		for (final String field : vendorSpecificFields)
		{
			if (StringUtils.isNotBlank(parameters.get(field)))
			{
				vendorParameters.put(field, parameters.get(field));
			}
		}

		return new AnnotationHashMap(vendorParameters);
	}

	/**
	 * Create the address.
	 * 
	 * @param parameters Address fields
	 * @return A cis address
	 */
	private CisAddress setAddressInformation(final Map<String, String> parameters)
	{
		final CisAddress address = new CisAddress();

		address.setEmail(parameters.get(FIELD_EMAIL));
		address.setFirstName(parameters.get(FIELD_FIRST_NAME));
		address.setLastName(parameters.get(FIELD_LAST_NAME));
		address.setPhone(parameters.get(FIELD_PHONE_NUMBER));
		address.setAddressLine1(parameters.get(FIELD_STREET_1));
		address.setAddressLine2(parameters.get(FIELD_STREET_2));
		address.setCity(parameters.get(FIELD_CITY));
		address.setState(parameters.get(FIELD_STATE));
		address.setZipCode(parameters.get(FIELD_POSTAL_CODE));
		address.setCountry(parameters.get(FIELD_COUNTRY));

		return address;
	}

	private CisCreditCard getCreditCard(final Map<String, String> parameters)
	{
		final CisCreditCard creditCard = new CisCreditCard();

		final String accountNumber = StringUtils.checkPrecondition(parameters, FIELD_ACCOUNT_NUMBER);
		creditCard.setCcNumber(accountNumber);

		String expirationYear = StringUtils.checkPrecondition(parameters, FIELD_EXPIRATION_YEAR);
		if (expirationYear.length() > 2)
		{
			expirationYear = expirationYear.substring(expirationYear.length() - 2);
		}
		final String expirationMonth = StringUtils.checkPrecondition(parameters, FIELD_EXPIRATION_MONTH);

		creditCard.setExpirationMonth(Integer.parseInt(expirationMonth));
		creditCard.setExpirationYear(Integer.parseInt(expirationYear));

		final String cardType = StringUtils.checkPrecondition(parameters, FIELD_CC_TYPE);
		creditCard.setCardType(cardType);
		creditCard.setCvc(parameters.get(FIELD_CV_NUM));

		return creditCard;
	}

	private CisPaymentTransactionResult createAuthTransaction(final Map<String, String> parameters)
	{
		final CisPaymentTransactionResult validationResult = new CisPaymentTransactionResult();
		validationResult.setVendorReasonCode(parameters.get(FIELD_AUTH_REASON_CODE));
		validationResult.setVendorStatusCode(parameters.get(FIELD_AUTH_CODE));
		if (StringUtils.isNotBlank(validationResult.getVendorReasonCode()))
		{
			final CisDecision authDecision = this.reasonCodesMapping.get(validationResult.getVendorReasonCode());
			validationResult.setDecision(authDecision);
		}
		validationResult.setClientAuthorizationId(parameters.get(FIELD_ORDER_NUMBER));
		validationResult.setTransactionVerificationKey(parameters.get(FIELD_SUBSCRIPTION_SIGN));
		final String transID = StringUtils.checkPrecondition(parameters, FIELD_REQUEST_ID);
		validationResult.setId(transID);
		return validationResult;
	}

	public SubscriptionServiceData getSubscriptionServiceData()
	{
		return this.subscriptionServiceData;
	}

	@Required
	public void setSubscriptionServiceData(final SubscriptionServiceData subscriptionServiceData)
	{
		this.subscriptionServiceData = subscriptionServiceData;
	}

    public CyberSourceErrorHandler getCyberSourceErrorHandler()
    {
        return cyberSourceErrorHandler;
    }

    @Required
    public void setCyberSourceErrorHandler(CyberSourceErrorHandler cyberSourceErrorHandler)
    {
        this.cyberSourceErrorHandler = cyberSourceErrorHandler;
    }
}
