package com.cybersource.hybris.util;

import java.util.ArrayList;
import java.util.List;

public class CyberSourceConstant {

	public final static String ACCESS_KEY = "access_key";
	public final static String PROFILE_ID = "profile_id";
	public final static String TRANSACTION_UUID = "transaction_uuid";
	public final static String SIGNED_DATE_TIME = "signed_date_time";
	public final static String LOCALE = "locale";
	public final static String TRANSACTION_TYPE = "transaction_type";
	public final static String REFERENCE_NUMBER = "reference_number";
	public final static String AMOUNT = "amount";
	public final static String CURRENCY = "currency";
	public final static String PAYMENT_METHOD = "payment_method";
	public final static String BILL_TO_FORENAME = "bill_to_forename";
	public final static String BILL_TO_SURNAME = "bill_to_surname";
	public final static String BILL_TO_EMAIL = "bill_to_email";
	public final static String BILL_TO_PHONE = "bill_to_phone";
	public final static String BILL_TO_ADDRESS_LINE1 = "bill_to_address_line1";
	public final static String BILL_TO_ADDRESS_CITY = "bill_to_address_city";
	public final static String BILL_TO_ADDRESS_STATE = "bill_to_address_state";
	public final static String BILL_TO_ADDRESS_COUNTRY = "bill_to_address_country";
	public final static String BILL_TO_ADDRESS_POSTAL_CODE = "bill_to_address_postal_code";

	public final static String CARD_TYPE = "card_type";
	public final static String CARD_NUMBER = "card_number";
	public final static String CARD_EXPIRY_DATE = "card_expiry_date";

	public final static String ACCEPT = "ACCEPT";
	public final static String REJECT = "REJECT";
	public final static String REVIEW = "REVIEW";
	public final static String ERROR = "ERROR";

	public final static String INVALID_FIELD = "InvalidField";
	public final static String MISSING_FIELD = "MissingField";

	public static List<String> signedFieldsList = new ArrayList<String>();
	public static List<String> unsignedFieldsList = new ArrayList<String>();

	static {
		unsignedFieldsList.add(CARD_TYPE);
		unsignedFieldsList.add(CARD_NUMBER);
		unsignedFieldsList.add(CARD_EXPIRY_DATE);

		signedFieldsList.add(ACCESS_KEY);
		signedFieldsList.add(PROFILE_ID);
		signedFieldsList.add(TRANSACTION_UUID);
		signedFieldsList.add(SIGNED_DATE_TIME);
		signedFieldsList.add(LOCALE);
		signedFieldsList.add(TRANSACTION_TYPE);
		signedFieldsList.add(REFERENCE_NUMBER);
		signedFieldsList.add(AMOUNT);
		signedFieldsList.add(CURRENCY);
		signedFieldsList.add(PAYMENT_METHOD);
		signedFieldsList.add(BILL_TO_FORENAME);
		signedFieldsList.add(BILL_TO_SURNAME);
		signedFieldsList.add(BILL_TO_EMAIL);
		signedFieldsList.add(BILL_TO_PHONE);
		signedFieldsList.add(BILL_TO_ADDRESS_LINE1);
		signedFieldsList.add(BILL_TO_ADDRESS_CITY);
		signedFieldsList.add(BILL_TO_ADDRESS_STATE);
		signedFieldsList.add(BILL_TO_ADDRESS_COUNTRY);
		signedFieldsList.add(BILL_TO_ADDRESS_POSTAL_CODE);
	}

}
