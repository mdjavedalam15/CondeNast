/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.dummyvendor.model;

import java.math.BigDecimal;

/**
 * Representation of a sample vendor specific request DTO.
 * 
 */
public class DummyVendorAuthorizationRequest
{
    /** ID provided by the client that is unique per authorization (e.g. the shipment, return or order id) */
    private String clientAuthorizationId;

    /** The amount of the transaction. */
    private BigDecimal amount;

    /** 3 letter ISO 4217 currency code. */
    private String currency;

    /**
     * A sample vendor specific parameter
     */
    private String vendorSpecificParameter;

    /**
     *
     * @return the amount
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     *
     * @param amount the amount
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     *
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     *
     * @param currency the currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     *
     * @return vendor specific parameter
     */
    public String getVendorSpecificParameter() {
        return vendorSpecificParameter;
    }

    /**
     *
     * @param vendorSpecificParameter vendor specific parameter
     */
    public void setVendorSpecificParameter(String vendorSpecificParameter) {
        this.vendorSpecificParameter = vendorSpecificParameter;
    }

    /**
     *
     * @return the clientAuthorizationId
     */
    public String getClientAuthorizationId() {
        return clientAuthorizationId;
    }

    /**
     *
     * @param clientAuthorizationId
     */
    public void setClientAuthorizationId(String clientAuthorizationId) {
        this.clientAuthorizationId = clientAuthorizationId;
    }
}
