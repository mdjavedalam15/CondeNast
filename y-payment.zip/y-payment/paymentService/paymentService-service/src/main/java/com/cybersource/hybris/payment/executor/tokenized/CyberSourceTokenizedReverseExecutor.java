package com.cybersource.hybris.payment.executor.tokenized;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.cybersource.stub.CCAuthReversalService;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisPaymentRequest;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentTransactionResult;

import javax.annotation.Resource;
import java.math.BigDecimal;

public class CyberSourceTokenizedReverseExecutor
		extends
		AbstractSimpleServiceMethodExecutor<Pair<String, CisPaymentRequest>, CisTokenizedPaymentTransactionResult, RequestMessage, ReplyMessage> {
	@Resource
	WebServiceClient webServiceClient;

	@Resource
	CyberSourceErrorHandler cyberSourceErrorHandler;

	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			final Pair<String, CisPaymentRequest> request) {
		final RequestMessage requestMessage = new RequestMessage();

		// Set value(s) of purchase totals. The grand total has to be the
		// previous authorized amount.
		requestMessage.setPurchaseTotals(CyberSourcePopulator
				.getPurchaseTotal(request.getValue()));

		// Indicate that it's a reverse request
		final CCAuthReversalService ccAuthReversalService = new CCAuthReversalService();
		ccAuthReversalService.setAuthRequestID(request.getKey());
		ccAuthReversalService.setRun("true");
		requestMessage.setCcAuthReversalService(ccAuthReversalService);
		return requestMessage;
	}

	@Override
	protected CisTokenizedPaymentTransactionResult convertResponse(
			final Pair<String, CisPaymentRequest> request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisTokenizedPaymentTransactionResult cisResult = new CisTokenizedPaymentTransactionResult();
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));

		if (CisDecision.REJECT.equals(cisResult.getDecision())) {
			cyberSourceErrorHandler.determineErrorCodes(
					CyberSourcePopulator.prepareErrorFields(replyMessage),
					replyMessage.getReasonCode().toString());
		}

		cisResult.setRequest(request.getValue());
		if (replyMessage.getCcAuthReversalReply() != null
				&& replyMessage.getCcAuthReversalReply().getAmount() != null) {
			cisResult.setAmount(new BigDecimal(replyMessage
					.getCcAuthReversalReply().getAmount()));
		}

		return cisResult;
	}

}