/*
 * [y] hybris Platform
 * 
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 */
package com.cybersource.hybris.payment.executor;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybersource.hybris.WebServiceClient;
import com.cybersource.hybris.payment.handler.CyberSourceErrorHandler;
import com.cybersource.hybris.util.CSUtil;
import com.cybersource.hybris.util.CyberSourcePopulator;
import com.cybersource.stub.PayerAuthEnrollReply;
import com.cybersource.stub.PayerAuthEnrollService;
import com.cybersource.stub.RecurringSubscriptionInfo;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.api.executor.AbstractSimpleServiceMethodExecutor;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.common.utils.StringUtils;
import com.hybris.cis.common.utils.SubscriptionServiceData;

/**
 * 
 */
public class CyberSourcePayerAuthExecutor
		extends
		AbstractSimpleServiceMethodExecutor<Pair<String, CisPaymentAuthorization>, CisPaymentTransactionResult, RequestMessage, ReplyMessage> {

	private static final Logger LOG = LoggerFactory
			.getLogger(CyberSourcePayerAuthExecutor.class);

	@Resource
	SubscriptionServiceData subscriptionServiceData;

	@Resource
	WebServiceClient webServiceClient;

	@Resource
	CyberSourceErrorHandler cyberSourceErrorHandler;

	@Override
	protected ReplyMessage process(final RequestMessage requestMessage) {
		return webServiceClient.sendReceive(requestMessage);
	}

	@Override
	protected RequestMessage convertRequest(
			Pair<String, CisPaymentAuthorization> request) {
		final RequestMessage requestMessage = new RequestMessage();

		final CisPaymentAuthorization paymentRequest = request.getValue();

		// Set subscription ID (profile ID)
		final RecurringSubscriptionInfo recurringSubscriptionInfo = new RecurringSubscriptionInfo();
		recurringSubscriptionInfo.setSubscriptionID(request.getKey());
		requestMessage.setRecurringSubscriptionInfo(recurringSubscriptionInfo);

		// Set value(s) of purchase totals
		requestMessage.setPurchaseTotals(CyberSourcePopulator.getPurchaseTotal(paymentRequest));
		
		AnnotationHashMap parameters = paymentRequest.getParameters();
		Map<String, String> map = parameters.getMap();

		requestMessage.setMerchantReferenceCode(paymentRequest.getClientAuthorizationId());
		
		
		if (map != null) {
			if (StringUtils.isNotBlank(map.get("clientAuthorizationId"))) {
				requestMessage.setMerchantReferenceCode(map.get("clientAuthorizationId"));
			}
			
			String deviceFingerPrint = map.get("req_device_fingerprint_id");
			if (StringUtils.isNotBlank(deviceFingerPrint)) {
				requestMessage.setDeviceFingerprintID(deviceFingerPrint);			
			}
		}
		PayerAuthEnrollService service =  new PayerAuthEnrollService(); 
		requestMessage.setPayerAuthEnrollService(service);
		requestMessage.getPayerAuthEnrollService().setRun("true");
		
		return requestMessage;
	}

	@Override
	protected CisPaymentTransactionResult convertResponse(
			Pair<String, CisPaymentAuthorization> request,
			final RequestMessage requestMessage, final ReplyMessage replyMessage) {
		final CisPaymentTransactionResult cisResult = new CisPaymentTransactionResult();
		
		CSUtil.log(LOG, replyMessage, replyMessage.getPayerAuthEnrollReply());
		cisResult.setDecision(CyberSourcePopulator
				.convertToCisDecision(replyMessage.getDecision()));

		
		if (CisDecision.REJECT.equals(cisResult.getDecision())) {
			replyMessage.setDecision("ACCEPT");
			cisResult.setDecision(CisDecision.ACCEPT);
		}
		
		CisPaymentAuthorization requestOrig = request.getValue();
		cisResult.setRequest(request.getValue());
		cisResult.setId(replyMessage.getRequestID());
		
		cisResult.setClientAuthorizationId(requestOrig.getClientAuthorizationId());
		cisResult.setAmount(requestOrig.getAmount());

		
		cisResult.setVendorReasonCode(String.valueOf(replyMessage.getReasonCode()));
	
		Map <String, String> map = new HashMap<String, String>();
		
		PayerAuthEnrollReply payerAuthEnrollReply = replyMessage.getPayerAuthEnrollReply();
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getAcsURL())) {
			map.put("acsURL", payerAuthEnrollReply.getAcsURL());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getCommerceIndicator())) {
			map.put("commerceIndicator", payerAuthEnrollReply.getCommerceIndicator());	
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getEci())) {
			map.put("eci", payerAuthEnrollReply.getEci());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getPaReq())) {
				map.put("paReq", payerAuthEnrollReply.getPaReq());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getProxyPAN())) {
				map.put("proxyPAN", payerAuthEnrollReply.getProxyPAN());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getXid())) {
				map.put("xid", payerAuthEnrollReply.getXid());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getProofXML())) {
			map.put("proofXML", payerAuthEnrollReply.getProofXML());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getUcafCollectionIndicator())) {
				map.put("ucafCollectionIndicator", payerAuthEnrollReply.getUcafCollectionIndicator());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getVeresEnrolled())) {
			map.put("veresEnrolled", payerAuthEnrollReply.getVeresEnrolled());
		}
		if (StringUtils.isNotBlank(payerAuthEnrollReply.getAuthenticationPath())) {
			map.put("authenticationPath", payerAuthEnrollReply.getAuthenticationPath());
		}
	
		cisResult.setVendorResponses(new AnnotationHashMap(map));
		
		CSUtil.log(LOG, cisResult.getVendorResponses());
		return cisResult;
	}

}
