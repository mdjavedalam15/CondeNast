/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.hybris.util;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.log4j.Logger;




/**
 *
 */
public class CSUtil
{


	public static void print(final Object... objs)
	{
		for (final Object o : objs)
		{
			if (o != null)
			{
				System.out.println(ReflectionToStringBuilder.toString(o, ToStringStyle.MULTI_LINE_STYLE));
			}
		}
	}

	public static void log(final org.slf4j.Logger LOG, final Object... objs)
	{
		for (final Object o : objs)
		{
			if (o != null)
			{
				LOG.info(ReflectionToStringBuilder.toString(o, ToStringStyle.MULTI_LINE_STYLE));
			}
		}
	}
	
	public static void log(final Logger LOG, final Object... objs)
	{
		for (final Object o : objs)
		{
			if (o != null)
			{
				LOG.info(ReflectionToStringBuilder.toString(o, ToStringStyle.MULTI_LINE_STYLE));
			}
		}
	}
}
