/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.util.Collections;

import org.junit.Assert;

import org.junit.Test;

import com.hybris.cis.api.model.CisDecision;


/**
 *
 */
public class CCAuthCaptureServiceTest extends BaseServiceTest
{
	@Test
	public void test()
	{
		final ReplyMessage replyMessageAuth = authorize();

		final RequestMessage requestMessageCapture = new RequestMessage();

		requestMessageCapture.setCcCaptureService(new CCCaptureService());
		requestMessageCapture.getCcCaptureService().setRun("true");

		// specify the request id of previously submitted authorization
		requestMessageCapture.getCcCaptureService().setAuthRequestID(replyMessageAuth.getRequestID());
		// specify items
		requestMessageCapture.getItems().add(items[0]);
		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessageCapture);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcCaptureReply());
		Assert.assertEquals(CisDecision.ACCEPT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
		
	}


	@Test
	public void testFailMissingFields()
	{
		final RequestMessage requestMessage = new RequestMessage();

		requestMessage.setCcCaptureService(new CCCaptureService());
		requestMessage.getCcCaptureService().setRun("true");

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcCaptureReply());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(1, replyMessage.getMissingFields().size(), 1);
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}
}
