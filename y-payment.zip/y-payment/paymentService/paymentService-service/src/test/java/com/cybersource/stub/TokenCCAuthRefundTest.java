package com.cybersource.stub;

import com.cybersource.hybris.util.CSUtil;
import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

/**
 * Created by artlaber on 01.12.14.
 */
public class TokenCCAuthRefundTest extends TokenBaseServiceTest {

	@Test
	public void testRefund()
	{
		final CisPaymentTransactionResult reply = authorize();
		final CisPaymentTransactionResult reply2 =  paymentService.capture( paymentRequest, reply.getId(), reply.getClientAuthorizationId());
		final CisPaymentTransactionResult reply3 =  paymentService.refund( paymentRequest, reply2.getId(), reply2.getClientAuthorizationId());

		Assert.assertNotNull(reply3);
		Assert.assertEquals(CisDecision.ACCEPT, reply3.getDecision());
	}

}
