/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.util.Collections;

import org.junit.Assert;

import org.junit.Test;

import com.hybris.cis.api.model.CisDecision;


/**
 *
 */

public class CCAuthReversalServiceTest extends BaseServiceTest
{

	@Test
	public void testOK()
	{
		final ReplyMessage replyMessageAuth = authorize();

		final RequestMessage requestMessageReversal = new RequestMessage();

		requestMessageReversal.setCcAuthReversalService(new CCAuthReversalService());
		requestMessageReversal.getCcAuthReversalService().setRun("true");
		requestMessageReversal.getCcAuthReversalService().setAuthRequestID(replyMessageAuth.getRequestID());

		// specify currency
		requestMessageReversal.setPurchaseTotals(purchaseTotals);

		// specify items in authorization
		requestMessageReversal.getItems().add(items[0]);
		requestMessageReversal.getItems().add(items[1]);

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessageReversal);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcAuthReversalReply());
		Assert.assertEquals(CisDecision.ACCEPT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}

	@Test
	public void testFailMissingFields()
	{
		final RequestMessage requestMessage = new RequestMessage();

		requestMessage.setCcAuthReversalService(new CCAuthReversalService());
		requestMessage.getCcAuthReversalService().setRun("true");
		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcAuthReversalReply());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));

		// number of fields missing
		Assert.assertEquals(3, replyMessage.getMissingFields().size());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}
}
