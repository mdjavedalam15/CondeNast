/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.util.Collections;

import org.junit.Assert;
import org.junit.Test;

import com.cybersource.hybris.util.CSUtil;
import com.hybris.cis.api.model.CisDecision;


/**
 *
 */
public class PayerAuthEnrollServiceTest extends BaseServiceTest
{
	
	
	@Test
	public void testNotEnrolledToken()
	{
		
		PayerAuthEnrollService service =  new PayerAuthEnrollService(); 
		requestMessage.setPayerAuthEnrollService(service);
		requestMessage.getPayerAuthEnrollService().setRun("true");
		requestMessage.setMerchantReferenceCode("1");
		
		// Set subscription ID (profile ID)
//		final RecurringSubscriptionInfo recurringSubscriptionInfo = new RecurringSubscriptionInfo();
//		recurringSubscriptionInfo.setSubscriptionID("9997000204661363");
//		requestMessage.setRecurringSubscriptionInfo(recurringSubscriptionInfo);
		
		requestMessage.setPurchaseTotals(purchaseTotals);
		// 4000000000000002
		card.setAccountNumber("4000000000000002");

		requestMessage.setCard(card);

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);
		PayerAuthEnrollReply payerAuthEnrollReply = replyMessage.getPayerAuthEnrollReply();

		CSUtil.print(payerAuthEnrollReply);
		CSUtil.print(requestMessage, replyMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
	//	Assert.assertEquals(1, replyMessage.getInvalidFields().size());
	//	Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
	}
	@Test
	public void testNotEnrolled()
	{
		requestMessage.setPayerAuthEnrollService(new PayerAuthEnrollService());
		requestMessage.getPayerAuthEnrollService().setRun("true");
		requestMessage.setMerchantReferenceCode("1");
		requestMessage.setPurchaseTotals(purchaseTotals);
		requestMessage.setCard(card);
		


		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		CSUtil.print(requestMessage, replyMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
	//	Assert.assertEquals(1, replyMessage.getInvalidFields().size());
	//	Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
	}

	@Test
	public void testMissingFields()
	{
		final RequestMessage requestMessage = new RequestMessage();
		requestMessage.setMerchantReferenceCode("1");
		requestMessage.setPayerAuthEnrollService(new PayerAuthEnrollService());
		requestMessage.getPayerAuthEnrollService().setRun("true");

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertEquals(4, replyMessage.getMissingFields().size());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
	}
}
