package com.cybersource.hybris;

import org.apache.log4j.Logger;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.cybersource.hybris.util.CSUtil;
import com.cybersource.stub.ReplyMessage;
import com.cybersource.stub.RequestMessage;
import com.hybris.cis.common.utils.StringUtils;


/**
 *
 */
public class WebServiceClientTest extends WebServiceTemplate
{
	private static final Logger LOG = Logger.getLogger(WebServiceClient.class);
	

	public static String TEST_SERVER_URL = "https://ics2wstest.ic3.com/commerce/1.x/transactionProcessor";
	public static String PROD_SERVER_URL = "https://ics2ws.ic3.com/commerce/1.x/transactionProcessor";
	public static String SERVER_URL = TEST_SERVER_URL;
	public static final String MERCHANT_ID = "montrose";
	public String merchantID;
	
	public static String CLIENT_LIBRARY = "hybris";
	public static String LIB_VERSION = "1.0.0";

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public ReplyMessage sendReceive(final RequestMessage requestMessage)
	{
		ReplyMessage replyMessage = null;
		try
		{
			setDefaultUri(SERVER_URL);

			requestMessage.setMerchantID(MERCHANT_ID);

			// Before using this example, replace the generic value with
			// your reference number for the current transaction.
			if (StringUtils.isBlank(requestMessage.getMerchantReferenceCode())) {
				requestMessage.setMerchantReferenceCode("1");	
				requestMessage.setMerchantTransactionIdentifier("1");
			}

			// To help us troubleshoot any problems that you may encounter,
			// please include the following information about your application.
			requestMessage.setClientLibrary(CLIENT_LIBRARY);
			requestMessage.setClientLibraryVersion(LIB_VERSION);
			requestMessage.setClientEnvironment(System.getProperty("os.name") + "/" + System.getProperty("os.version") + "/"
					+ System.getProperty("java.vendor") + "/" + System.getProperty("java.version"));

			replyMessage = (ReplyMessage) marshalSendAndReceive(requestMessage);

		//	CSUtil.log(LOG, requestMessage, replyMessage);
			
		}
		catch (final Exception e)
		{
			LOG.error(e);
		}
		return replyMessage;
	}
}
