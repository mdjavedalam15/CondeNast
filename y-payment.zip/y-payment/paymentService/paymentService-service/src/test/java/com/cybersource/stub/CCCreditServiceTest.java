/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.util.Collections;

import org.junit.Assert;

import org.junit.Test;

import com.cybersource.hybris.util.CSUtil;
import com.hybris.cis.api.model.CisDecision;


/**
 *
 */
public class CCCreditServiceTest extends BaseServiceTest
{

	@Test
	public void test()
	{
		// 1. do authorize first
		final ReplyMessage replyMessageAuth = authorize();

		CSUtil.print(requestMessage, replyMessageAuth);
		System.out.println("-------------------------------");

		// 2. do capture
		final RequestMessage requestMessageCapture = new RequestMessage();

		requestMessageCapture.setCcCaptureService(new CCCaptureService());
		requestMessageCapture.getCcCaptureService().setRun("true");

		// specify the request id of previously submitted authorization
		requestMessageCapture.getCcCaptureService().setAuthRequestID(replyMessageAuth.getRequestID());
		// specify items
		requestMessageCapture.getItems().add(items[0]);
		requestMessageCapture.getItems().add(items[1]);
		requestMessageCapture.setPurchaseTotals(purchaseTotals);
		final ReplyMessage replyMessageCapture = webServiceClientTest.sendReceive(requestMessageCapture);
		//webServiceClient.sendReceive(requestMessageCapture);

		CSUtil.print(requestMessageCapture, replyMessageCapture);
		System.out.println("-------------------------------");
		// 3. do credit
		final RequestMessage requestMessageCredit = new RequestMessage();

		requestMessageCredit.setCcCreditService(new CCCreditService());
		requestMessageCredit.getCcCreditService().setRun("true");


		requestMessageCredit.getItems().add(items[0]);
		requestMessageCredit.getItems().add(items[1]);
		requestMessageCredit.setPurchaseTotals(purchaseTotals);
		requestMessageCredit.getCcCreditService().setCaptureRequestID(replyMessageAuth.getRequestID());

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessageCredit);

		CSUtil.print(requestMessageCredit, replyMessage);


		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcCreditReply());
		Assert.assertEquals(CisDecision.ACCEPT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}


	@Test
	public void testFailMissingFields()
	{
		final RequestMessage requestMessage = new RequestMessage();

		requestMessage.setCcCreditService(new CCCreditService());
		requestMessage.getCcCreditService().setRun("true");

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcCreditReply());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(6, replyMessage.getMissingFields().size());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}
}
