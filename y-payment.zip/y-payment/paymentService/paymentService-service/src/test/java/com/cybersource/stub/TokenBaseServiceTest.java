/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.payment.model.CisCreditCard;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.service.PaymentService;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "file:src/main/resources/META-INF/paymentService-service-spring.xml", "/paymentService-service-test-spring.xml" })
public class TokenBaseServiceTest {

	@Resource(name = "cyberSourcePaymentService")
	PaymentService paymentService;

	final String profileId = "9997000181049988";

	CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization();
	final CisCreditCard card = new CisCreditCard();

	final Item[] items = new Item[2];

	@Before
	public void prepareData() throws Exception {

		paymentRequest.setCurrency("USD");
		paymentRequest.setAmount(new BigDecimal("34.99"));

		AnnotationHashMap map = paymentRequest.getParameters();
		for(String s : map.getMap().keySet()) {
			System.out.println("Mapped " + s + " = " + map.getMap().get(s));
		}

		final Item item1 = new Item();
		item1.setId(new BigInteger("0"));
		item1.setUnitPrice("100.00");
		item1.setQuantity(new BigInteger("2"));
		items[0] = item1;

		final Item item2 = new Item();
		item2.setId(new BigInteger("1"));
		item2.setUnitPrice("100.00");
		item2.setQuantity(new BigInteger("1"));
		items[1] = item2;
	}

	public CisPaymentTransactionResult authorize() {
		return paymentService.authorize(paymentRequest, profileId);
	}

	@Test
	public void testData() {
		Assert.assertNotNull(paymentRequest);
	}

}
