/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.math.BigInteger;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cybersource.hybris.WebServiceClientTest;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "file:src/main/resources/META-INF/paymentService-service-spring.xml", "/paymentService-service-test-spring.xml" })
public class BaseServiceTest {

	@Resource
	WebServiceClientTest webServiceClientTest;

	RequestMessage requestMessage = new RequestMessage();
	final BillTo billTo = new BillTo();
	final Card card = new Card();
	final PurchaseTotals purchaseTotals = new PurchaseTotals();
	final Item[] items = new Item[2];

	@Before
	public void prepareData() throws Exception {
		billTo.setFirstName("John");
		billTo.setLastName("Doe");
		billTo.setStreet1("1295 Charleston Road");
		billTo.setCity("Mountain View");
		billTo.setState("CA");
		billTo.setPostalCode("94043");
		billTo.setCountry("US");
		billTo.setEmail("null@cybersource.com");
		billTo.setIpAddress("10.7.111.111");

		card.setAccountNumber("4111111111111111");
		card.setExpirationMonth(new BigInteger("12"));
		card.setExpirationYear(new BigInteger("2020"));

		purchaseTotals.setCurrency("USD");

		final Item item1 = new Item();
		item1.setId(new BigInteger("0"));
		item1.setUnitPrice("100.00");
		item1.setQuantity(new BigInteger("2"));
		items[0] = item1;

		final Item item2 = new Item();
		item2.setId(new BigInteger("1"));
		item2.setUnitPrice("100.00");
		item2.setQuantity(new BigInteger("1"));
		items[1] = item2;
	}

	public ReplyMessage authorize() {
		requestMessage.setCcAuthService(new CCAuthService());
		requestMessage.getCcAuthService().setRun("true");
		requestMessage.setBillTo(billTo);
		requestMessage.setCard(card);
		requestMessage.setPurchaseTotals(purchaseTotals);
		requestMessage.getItems().add(items[0]);
		requestMessage.getItems().add(items[1]);

		return webServiceClientTest.sendReceive(requestMessage);
	}

	@Test
	public void testData() {
		Assert.assertNotNull(requestMessage);
	}

}
