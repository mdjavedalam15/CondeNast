package com.cybersource.stub;

import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentReverse;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentTransactionResult;
import org.junit.Assert;
import org.junit.Test;

import java.util.Collections;

/**
 * Created by artlaber on 01.12.14.
 */
public class TokenCCAuthReverseTest extends TokenBaseServiceTest {

	@Test
	public void testOK()
	{
		final CisPaymentTransactionResult replyAuth = authorize();

		CisTokenizedPaymentReverse request = new CisTokenizedPaymentReverse();
		request.setAuthorizationRequestId(replyAuth.getClientAuthorizationId());
		request.setAuthorizationRequestToken(replyAuth.getId());
		request.setAmount(replyAuth.getRequest().getAmount());
		request.setCurrency(replyAuth.getRequest().getCurrency());

		final CisTokenizedPaymentTransactionResult replyReverse =  paymentService.reverse(request, replyAuth.getId());

		Assert.assertNotNull(replyReverse);
		Assert.assertEquals(CisDecision.ACCEPT, replyReverse.getDecision());
	}
}
