package com.cybersource.hybris.payment;

import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.service.PaymentService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


/**
 * Partial test only - validates the spring integration for the fraud service implementation.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( locations=
        { "/paymentService-service-test-spring.xml" })
public class MyPaymentServiceImplTest
{
//    @Autowired
//    @Qualifier("myPaymentService")
//    private PaymentService paymentService;

    @Test
    public void createsAuthorization()
    {
//        final String id = "id";
//        final CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization(id);
//        final CisPaymentTransactionResult result = paymentService.authorize(paymentRequest, id);
//        assertNotNull(result);
//        assertEquals(CisDecision.ACCEPT, result.getDecision());
    }
}