package com.cybersource.hybris.cis.api.payment.service;

import java.math.BigDecimal;

import javax.annotation.Resource;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cybersource.hybris.util.CSUtil;
import com.hybris.cis.api.model.AnnotationHashMap;
import com.hybris.cis.api.model.CisAddress;
import com.hybris.cis.api.model.Pair;
import com.hybris.cis.api.payment.model.CisCreditCard;
import com.hybris.cis.api.payment.model.CisCreditCardAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentAuthorization;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.service.PaymentService;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( locations=
        { "file:src/main/resources/META-INF/paymentService-service-spring.xml", "/paymentService-service-test-spring.xml" })


public class CyberSourcePaymentServiceTest {
	
	@Resource(name = "cyberSourcePaymentService")
	PaymentService paymentService;

	@Before 
	public void before() {
	// set the defaulturi of web client to test url 	
	}
	
	
	@Test
	public void testAuthorize()
	{
		final CisCreditCardAuthorization paymentRequest = new CisCreditCardAuthorization();
		paymentRequest.setAddress(new CisAddress());
		paymentRequest.getAddress().setFirstName("Tom");
		paymentRequest.getAddress().setLastName("Smith");
		paymentRequest.getAddress().setAddressLine1("10 Maple");
		paymentRequest.getAddress().setAddressLine2("RR 102");
		paymentRequest.getAddress().setAddressLine3("");
		paymentRequest.getAddress().setAddressLine4("");


		paymentRequest.getAddress().setCity("Ottawa");
		paymentRequest.getAddress().setState("ON");
		paymentRequest.getAddress().setZipCode("K1C2M8");
		paymentRequest.getAddress().setCountry("Canada");
		paymentRequest.getAddress().setEmail("null@cybersource.com");
		// TODO YM Is this device fingerprinting???


		paymentRequest.setCreditCard(new CisCreditCard());
		paymentRequest.getCreditCard().setCvc("123");
		paymentRequest.getCreditCard().setCardType("001");
		paymentRequest.getCreditCard().setCardHolder("Tom Smith");
		paymentRequest.getCreditCard().setCcNumber("4111111111111111");
		paymentRequest.getCreditCard().setExpirationMonth(10);
		paymentRequest.getCreditCard().setExpirationYear(2020);

		paymentRequest.setCurrency("USD");
		paymentRequest.setAmount(new BigDecimal("34.99"));
		
		AnnotationHashMap map = paymentRequest.getParameters();
		for(String s : map.getMap().keySet()) {
			System.out.println("Mapped " + s + " = " + map.getMap().get(s));
		}

		final CisPaymentTransactionResult reply = paymentService.authorize(paymentRequest);
		CSUtil.print(reply);
	}

	@Test
	public void testAuthorizeWithProfile()
	{
		final String profileId = "9997000181049988";
		final CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization();

		paymentRequest.setCurrency("USD");
		paymentRequest.setAmount(new BigDecimal("34.99"));
		
		AnnotationHashMap map = paymentRequest.getParameters();
		for(String s : map.getMap().keySet()) {
			System.out.println("Mapped " + s + " = " + map.getMap().get(s));
		}
		final CisPaymentTransactionResult reply = paymentService.authorize(paymentRequest, profileId);
		CSUtil.print(reply);
	}


	@Test
	public void testReversal()
	{
		final String profileId = "9997000181049988";
		final CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization();

		paymentRequest.setCurrency("USD");
		paymentRequest.setAmount(new BigDecimal("34.99"));
		
		final CisPaymentTransactionResult reply = paymentService.authorize(paymentRequest, profileId);
		
		//final CisPaymentTransactionResult reply2 =  paymentService.capture( paymentRequest, reply.getId(), reply.getClientAuthorizationId());
		
		final CisPaymentTransactionResult reply2 =  paymentService.reverse( paymentRequest, reply.getId(), reply.getClientAuthorizationId());
		
		CSUtil.print(reply, reply2);
	}

	
	@Test
	public void testRefund()
	{
		final String profileId = "9997000181049988";
		final CisPaymentAuthorization paymentRequest = new CisPaymentAuthorization();

		paymentRequest.setCurrency("USD");
		paymentRequest.setAmount(new BigDecimal("34.99"));
		
		final CisPaymentTransactionResult reply = paymentService.authorize(paymentRequest, profileId);
		
		final CisPaymentTransactionResult reply2 =  paymentService.capture( paymentRequest, reply.getId(), reply.getClientAuthorizationId());
		
		final CisPaymentTransactionResult reply3 =  paymentService.refund( paymentRequest, reply2.getId(), reply2.getClientAuthorizationId());
		
		CSUtil.print(reply, reply2, reply3);
	}

	
}
