/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.util.Collections;

import org.junit.Assert;

import org.junit.Test;

import com.hybris.cis.api.model.CisDecision;


/**
 *
 */
public class CcAuthServiceTest extends BaseServiceTest
{
	@Test
	public void test()
	{
		final ReplyMessage replyMessage = authorize();

		//CSUtil.print(requestMessage, replyMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcAuthReply());
		Assert.assertEquals(CisDecision.ACCEPT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}

	@Test
	public void testFailMissingFields()
	{
		requestMessage.setCcAuthService(new CCAuthService());
		requestMessage.getCcAuthService().setRun("true");

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertNotNull(replyMessage.getCcAuthReply());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
		Assert.assertEquals(6, replyMessage.getMissingFields().size());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	}
}
