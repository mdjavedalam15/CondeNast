/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2014 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.cybersource.stub;

import java.math.BigInteger;
import java.util.Collections;

import org.junit.Assert;
import org.junit.Test;

import com.cybersource.hybris.util.CSUtil;
import com.hybris.cis.api.model.CisDecision;


/**
 *
 */
public class PayerAuthValidateServiceTest extends BaseServiceTest
{
	@Test
	public void test()
	{
		
		
		
		String paRes = "eNqdmFuTqkgSgN+N8D90zD46M4Ci4oTdEcUdFJS7+gaI3EEucvv1W2r36Z4zHbtnt1+6SLOysiozv0pY60HpebTmubfSe1tLXlXZvvcSnl9/W85bXE7c0swHbJVnHd5W6G9v6z1Qveqh8BgtW08odDfwKO92agl7PxmyJMkoXKxeoXbjlVWYZ2/Yn+if0zXy8QgXKt3Azuq3te0WpCC/4YvVFFuskffHdeqVAv129i72LanXyPNxjXzO29/uowo63YXnN3kwZzIzr44z0XJmebezVjePVmfuAF7XyF1jfbZr722Kokt0MZ2/YPhfKPYXSqyRh3x9vZsDaX6DtnFsha2Rr5I1PJ7Sy9z+jcDRNfLjae111zzzoAbc3I/xGvl07mpnb+jf/6DqXbrWD2/rOky/OrW6O4Ut18hDvq5qu75Vb8c18j5au3bTvAEASGCxSaqA+zBSLevEMKzPDhO42YfK2nPDN3QOnYL/H7NA4udlWAfp3dW/C9bI3RXkEc+3tRb6GVys9F66NMlgFIO6vv6FIG3b/tnO/sxLH4EOowi6QqDCuQr9f/32nOWdheyS/0/TKDvLs9C1k3Cwa5gZklcH+fnlh2/fmdHVuyUMURnqD2jqDxfDsz/uEnSGzaFN5HujX3b2K6v87GxZ2X9UgY3dF/jJ0Nta9S7ePSO8F0MVXn/716+UBh36XlX/P658uPHVwoc9005u3pvDcsq2FtkdwQLf8/YF6R/oPrZkHn39mPfUXCM/fH/f2DOKX07rqajj3MESAFpK28nGUAmRt2Z9Ou3Pva14OBvHDY42Lpmd1NsmwX3fVZ0tyHfFRSSCaEtKU3PvYzybjkcHHBt2jeKTiFYO0rVvJlIeZVjDpR7npYUVou1+qigpesYs6rwhGjVdAnI1ATvicsETzVFWhNYK0XiEN54wHLuEWijEKeXFwF1szIQXrVI7r47KdSc0BdLbUVddq7oaJswlHBTCXM7r5oZLAxVPsBgnu3A8SthD2vZLWeJbvr72y8PUwut2tkkMIT6ZSYD2V45EZT3OFcztplRAwZ3vm1JuVm4FVMvhw00RT+XxaFH5+JwL6pbe4QAhrboT4mCTW+pK652ZFZVldyVrBBD0jskvbs8CfUr4r69fsuo9Mhuvf0biMEdXtF3bz5F2cyLPrWUbEoKSXym7PIeZnbzQXpq/PAJY/v6yMz5/AJQGBZ/PVJ5CnLre7y/bVwnyKof6mv66C8L89xfq1dDWyM/rPBamvLIOL7CuIC8lQaCtgaJApfmgFUjgCxTQhJZWjuImPwlB48pAYVhSAe0pYrYSiDmAGQwZSJRpSh2tgy3py+Z4BKdKJLPKbYvo+Ai4dykJcok15MBN1auTspUyXdWOZfbHqeHDce/SjCaR4GGRaltRipN4PDpZc9S2TldJVVrGP9KmotA0qI3TQUYFXsaOIUkrOvDYFu0kmumlyO3kCMxlWrShrH/KlG48+pBKPNFRAxCfPh11kJi6pKAt1T6sC0yr7m0uaSSFuO/8LuOZ9iTfPXFmArTEReD4viOd+bIjgZEbx8ISN5UTSTVa5mlxy7QdfTyIsW3NA4ciSQWTOl4HDjynhxVJZ5mvVtTEsQjfmCaZk5o9jAopREAm/bgI4pBbtSh5jwIAOwooBLj/Ph5R/gY+MaBgZmcsFNMiSMjzVMBEcs8aCxd3jxHY3iqYsQwjq5MudVaJfzjGtRzxnO/lM9Luao2DPi1wnMeWq8D2m2MqhZFHCm5bIwsN8ejtTV1JK4me0LPWdd2dATlzBkEsXBtGWVj6FSWUuYFmQrYsx6OgEpZKsTPPAno+iGBIHDyomR7QG6OXWOHMJf0yadnKRKKdgipSRZLhTGtFg9asJLodlIkh7qf2djya+o58ODtkQ8bYlPeLAy3MhaO3uxpFg90a66Bez5I4ibtMQnuzwIVqOZuSQCNFIgvo465RM/4wFPx4hHqMFrSBG0gL+ridFE2Bc1TImy1h6tRteyu2lQKhvMl3Q1xh3Y6vUuUc28F8ekOkVqCBAsh8VrXjkac/c4hXJQZEAEhUy1EWxWmA4yaMANNSubABtnc582ZgsiQw5+Qez+NBTU4USZ8O4iOzx6PjlEVPOjg/rCk4vPQVQ/U51QgdU2mCjsJK0PhKvUV8LLaFlr/nlYpGJOm3bA6MixBK4RlDxyPM0ohQJj00lwIrRhebgfmuemn/yABZFw8MShyaY4mc5xcBzcTdbrW6mXsHVnCzmdY0K8eup5ba0agZjEpxD9/lQzetLZyu5Fkxr1DE6ubWdR82DetcGN1o9ZQL/NyJb+VFbCbLxXiE8LPZ1cfMk9wODjNPKxW7UpcTRaGqaNuT+LanbqcTHi7oclWspHK7x6Jb7E+GDsHPqEKUfmycKOb1CbCvvPoOYBRKQ4BF6ReAfXsErUf/KsDo4V5890J1JZh/iZOpjRsxnkS2T1j5ralM2f7EJbej1dHOFKthcKOTRtLjkTMTW0kVWgY8YUCDuNcs9W7lekrjjtWB/o4BiWbVxJ0pvpGumjP1d7CNR5J+RxszyLr8iTZd+SGTuON/BBsNnmCDllS85Z/+bGjS/ITTF4DdYeZmoGMioDwtVhKli+IJpjOs3NSG6IOWSOFxBqBttyZnDtDr4WwJvoIyrX8ifj558pl8KIQWJ4Kcg5vuW2yuQqgK9g7gnEtaNs9hg7Fw7PwiqPtsV7NcElyLZtFuba41LpfJPD5elxKT9oIh3XhGtkGjxqGo1T212sFWJN0t/OV5SxObjMMW1Coru4jISTydQSwZeDq5HK0dl6VBus8XQ0A2BVk1l2E1Cxh/c5AXzHkj30x/PLoVQ20twHbXGvLCIYuNos3uiQEAF3kDOX/PnzPTKpQEQLsFR/EonARwdHDFZ2SSJCzeWLWPa0w30NZXp+YN5kZw5swYnnDiPrIgie5QkEj0YY32FYskVSIUenF20M3TthdQdqn5PWuPR7qel5IOLg9YaBLD0cDySZXxoz2CWY6fHE9TjusyyrKLLBRbmEM/XR3G/eqAV4avkMRtYyCrGYGYmznFGmKoIMbuYE9Lvsc6MHMyDMN21CIhF9VZqZdyFChusNHDra5U/vyCFFoiY+PR9nS8NTgQNvpuc2K4MhQLoC/EuJhsDkFNa7gfFVc2I3bRqRDV5cUuGXVyduZzRNSa6433I6fTL0swHqVtCOt/oA0RN81beNwQesEm/dQsTZ59NFS/BIEmghAIvQ8IiECku/2ESUw12EgA5Sit4DTBmdGPlDSAxPv/KB2Y3N8Uz9eugAafXcF/6nIgBP5Ln/PZ5fzoGmCX0z27HFZsHAiFe0mNR3zgyjD8nRQxM0k/trIOeusuix4y9IcsInFJqVrq6SvHtKJpDIwsgeqxMuwYQMvo0+DqDMz+fiYPELYtp1v3Al/1vwqJ8ei/YMKUSOkDEtI7JDRnukLhbBKC4PIRkfHoIyYwSQGkgQxoigyVDekrFO6VF6dRFYY6lMfVot4vlZ1VUDqYRhkyj2YrxEcK1JFCV6HU8aicTi7hMh42PdkrxSnmh6M4J2YIODQb0W7RmtWRaMZEZz/2OvOaHDWvYPbznUFLuG9rl2XBS765h2WysfNs2pQR31keZXZsiHc4mZ8TMbskCFJz0QYtZHqolzGCy57GWr1ThMp7p4CBVo+eNzuM3cfdLggDsjJTXLS4cxBUpzZJiyseugzzj7v9O93x6EObBg9tnQRGC8NJIsP3xe4rIGQJkktItpU8WfSY8NhmtgLBVBt8GdqRUTuLObYgavly5RhmVg68Q85zKWXcQ1c5Ti2o5K0J9kRa+94p4ZPbVhnQQp2403yetN541LXLKLkAvihglLWI2mz5W0Ugcp4t3ckyLLShVniJND1nOV209r7hBOfAbF3ZylfO3lcLy5heTwHsGDb9iV+Bb4sd+XxtQn68Sn2+ZD0+Jj2+dt2/f3z9CvZvluY1nw==";
		final RequestMessage requestMessage = new RequestMessage();

		requestMessage.setPayerAuthValidateService(new PayerAuthValidateService());
		requestMessage.getPayerAuthValidateService().setRun("true");
		requestMessage.getPayerAuthValidateService().setSignedPARes(paRes);

//		final PurchaseTotals purchaseTotals = new PurchaseTotals();
//		purchaseTotals.setCurrency("USD");
//		requestMessage.setPurchaseTotals(purchaseTotals);
//
//		final Card card = new Card();
//		card.setCardType("001");
//		card.setAccountNumber("4111111111111111");
//		card.setExpirationMonth(new BigInteger("12"));
//		card.setExpirationYear(new BigInteger("2015"));
//		requestMessage.setCard(card);

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);
		CSUtil.print(replyMessage.getPayerAuthValidateReply());
		Assert.assertNotNull(replyMessage);
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
	//	Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));


	}

	@Test
	public void testMissingFields()
	{
		final RequestMessage requestMessage = new RequestMessage();

		requestMessage.setPayerAuthValidateService(new PayerAuthValidateService());
		requestMessage.getPayerAuthValidateService().setRun("true");

		final ReplyMessage replyMessage = webServiceClientTest.sendReceive(requestMessage);

		Assert.assertNotNull(replyMessage);
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getMissingFields());
		Assert.assertEquals(Collections.EMPTY_LIST, replyMessage.getInvalidFields());
		Assert.assertEquals(CisDecision.REJECT, CisDecision.valueOf(replyMessage.getDecision()));
	}
}
