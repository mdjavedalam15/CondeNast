package com.cybersource.stub;

import com.hybris.cis.api.model.CisDecision;
import com.hybris.cis.api.payment.model.CisCaptureCompleteType;
import com.hybris.cis.api.payment.model.CisPaymentTransactionResult;
import com.hybris.cis.api.payment.model.CisTokenizedPaymentCapture;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by artlaber on 01.12.14.
 */
public class TokenCCAuthCaptureTest extends TokenBaseServiceTest {
	@Test
	public void testComplete()
	{
		final CisPaymentTransactionResult replyAuth = authorize();
		CisTokenizedPaymentCapture request = new CisTokenizedPaymentCapture();
		request.setAuthorizationRequestId(replyAuth.getClientAuthorizationId());
		request.setAuthorizationRequestToken(replyAuth.getId());
		request.setCompleteType(CisCaptureCompleteType.COMPLETE);
		request.setAmount(replyAuth.getAmount());
		request.setCurrency(replyAuth.getRequest().getCurrency());
		request.setParameters(replyAuth.getRequest().getParameters());

		final CisPaymentTransactionResult reply2 =  paymentService.capture(request, replyAuth.getId());

		Assert.assertNotNull(reply2);
		Assert.assertEquals(CisDecision.ACCEPT, reply2.getDecision());

	}

	@Test
	public void testNotComplete()
	{
		final CisPaymentTransactionResult replyAuth = authorize();
		CisTokenizedPaymentCapture request = new CisTokenizedPaymentCapture();
		request.setAuthorizationRequestId(replyAuth.getClientAuthorizationId());
		request.setAuthorizationRequestToken(replyAuth.getId());
		request.setCompleteType(CisCaptureCompleteType.NOT_COMPLETE);
		request.setAmount(replyAuth.getAmount());
		request.setCurrency(replyAuth.getRequest().getCurrency());
		request.setParameters(replyAuth.getRequest().getParameters());

		final CisPaymentTransactionResult reply2 =  paymentService.capture(request, replyAuth.getId());

		Assert.assertNotNull(reply2);
		Assert.assertEquals(CisDecision.ACCEPT, reply2.getDecision());

	}
}
